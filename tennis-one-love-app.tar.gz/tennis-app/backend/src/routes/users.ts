import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { prisma } from '../index.js';

// Validation schemas
const updateProfileSchema = z.object({
  firstName: z.string().min(1).max(50).optional(),
  lastName: z.string().max(50).optional(),
  city: z.string().max(100).optional(),
  photoUrl: z.string().url().optional(),
});

export default async function userRoutes(fastify: FastifyInstance) {
  /**
   * GET /api/users/rating
   * Get users rating list
   */
  fastify.get('/rating', async (request: FastifyRequest, reply: FastifyReply) => {
    const { limit = '20', offset = '0', search = '' } = request.query as any;

    try {
      const where = search ? {
        OR: [
          { firstName: { contains: search, mode: 'insensitive' as const } },
          { lastName: { contains: search, mode: 'insensitive' as const } },
          { username: { contains: search, mode: 'insensitive' as const } },
        ],
        isActive: true,
      } : { isActive: true };

      const [users, total] = await Promise.all([
        prisma.user.findMany({
          where,
          orderBy: { rating: 'desc' },
          take: parseInt(limit, 10),
          skip: parseInt(offset, 10),
          select: {
            id: true,
            firstName: true,
            lastName: true,
            username: true,
            photoUrl: true,
            rating: true,
            city: true,
            wins: true,
            losses: true,
          },
        }),
        prisma.user.count({ where }),
      ]);

      return reply.send({ users, total });
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to get rating' });
    }
  });

  /**
   * GET /api/users/:id
   * Get user profile
   */
  fastify.get('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };

    try {
      const user = await prisma.user.findUnique({
        where: { id: parseInt(id, 10) },
        select: {
          id: true,
          firstName: true,
          lastName: true,
          username: true,
          photoUrl: true,
          rating: true,
          city: true,
          wins: true,
          losses: true,
          createdAt: true,
        },
      });

      if (!user) {
        return reply.status(404).send({ error: 'User not found' });
      }

      return reply.send(user);
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to get user' });
    }
  });

  /**
   * PATCH /api/users/me
   * Update current user's profile
   */
  fastify.patch('/me', async (request: FastifyRequest, reply: FastifyReply) => {
    const token = request.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return reply.status(401).send({ error: 'Not authenticated' });
    }

    const body = updateProfileSchema.safeParse(request.body);
    if (!body.success) {
      return reply.status(400).send({ error: 'Invalid data', details: body.error.errors });
    }

    try {
      const session = await prisma.session.findUnique({
        where: { token },
        include: { user: true },
      });

      if (!session || session.expiresAt < new Date()) {
        return reply.status(401).send({ error: 'Session expired' });
      }

      const updatedUser = await prisma.user.update({
        where: { id: session.userId },
        data: body.data,
        select: {
          id: true,
          firstName: true,
          lastName: true,
          username: true,
          photoUrl: true,
          rating: true,
          city: true,
          wins: true,
          losses: true,
        },
      });

      return reply.send(updatedUser);
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to update profile' });
    }
  });

  /**
   * GET /api/users/:id/rating-history
   * Get user's rating history
   */
  fastify.get('/:id/rating-history', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { limit = '10' } = request.query as any;

    try {
      const history = await prisma.ratingHistory.findMany({
        where: { userId: parseInt(id, 10) },
        orderBy: { createdAt: 'desc' },
        take: parseInt(limit, 10),
        select: {
          rating: true,
          change: true,
          reason: true,
          createdAt: true,
        },
      });

      return reply.send(history.reverse()); // Return in chronological order
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to get rating history' });
    }
  });

  /**
   * GET /api/users/:id/games
   * Get user's games
   */
  fastify.get('/:id/games', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { limit = '10', offset = '0' } = request.query as any;
    const userId = parseInt(id, 10);

    try {
      const [games, total] = await Promise.all([
        prisma.game.findMany({
          where: {
            OR: [
              { player1Id: userId },
              { player2Id: userId },
            ],
          },
          orderBy: { playedAt: 'desc' },
          take: parseInt(limit, 10),
          skip: parseInt(offset, 10),
          include: {
            player1: { select: { id: true, firstName: true, lastName: true, rating: true } },
            player2: { select: { id: true, firstName: true, lastName: true, rating: true } },
            court: { select: { id: true, name: true } },
          },
        }),
        prisma.game.count({
          where: {
            OR: [
              { player1Id: userId },
              { player2Id: userId },
            ],
          },
        }),
      ]);

      return reply.send({ games, total });
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to get games' });
    }
  });

  /**
   * GET /api/users/:id/stats
   * Get user's statistics
   */
  fastify.get('/:id/stats', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };

    try {
      const user = await prisma.user.findUnique({
        where: { id: parseInt(id, 10) },
        select: { wins: true, losses: true },
      });

      if (!user) {
        return reply.status(404).send({ error: 'User not found' });
      }

      const totalGames = user.wins + user.losses;
      const winRate = totalGames > 0 ? Math.round((user.wins / totalGames) * 100) : 0;

      return reply.send({
        wins: user.wins,
        losses: user.losses,
        totalGames,
        winRate,
      });
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to get stats' });
    }
  });
}
