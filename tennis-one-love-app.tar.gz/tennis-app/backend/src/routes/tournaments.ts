import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../index.js';

export default async function tournamentRoutes(fastify: FastifyInstance) {
  /**
   * GET /api/tournaments
   * Get tournaments list
   */
  fastify.get('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const { status, limit = '20', offset = '0' } = request.query as any;

    try {
      const where: any = {};
      if (status) where.status = status;

      const [tournaments, total] = await Promise.all([
        prisma.tournament.findMany({
          where,
          orderBy: { startDate: 'asc' },
          take: parseInt(limit, 10),
          skip: parseInt(offset, 10),
          include: {
            court: { select: { id: true, name: true, address: true } },
            _count: { select: { participants: true } },
          },
        }),
        prisma.tournament.count({ where }),
      ]);

      const tournamentsWithCount = tournaments.map(t => ({
        ...t,
        currentParticipants: t._count.participants,
        _count: undefined,
      }));

      return reply.send({ tournaments: tournamentsWithCount, total });
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to get tournaments' });
    }
  });

  /**
   * GET /api/tournaments/:id
   * Get tournament by ID
   */
  fastify.get('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };

    try {
      const tournament = await prisma.tournament.findUnique({
        where: { id: parseInt(id, 10) },
        include: {
          court: true,
          participants: {
            include: {
              user: { 
                select: { 
                  id: true, 
                  firstName: true, 
                  lastName: true, 
                  rating: true 
                } 
              },
            },
            orderBy: { seed: 'asc' },
          },
        },
      });

      if (!tournament) {
        return reply.status(404).send({ error: 'Tournament not found' });
      }

      return reply.send(tournament);
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to get tournament' });
    }
  });

  /**
   * POST /api/tournaments/:id/register
   * Register for tournament
   */
  fastify.post('/:id/register', async (request: FastifyRequest, reply: FastifyReply) => {
    const token = request.headers.authorization?.replace('Bearer ', '');
    const { id } = request.params as { id: string };
    
    if (!token) {
      return reply.status(401).send({ error: 'Not authenticated' });
    }

    try {
      const session = await prisma.session.findUnique({
        where: { token },
        include: { user: true },
      });

      if (!session || session.expiresAt < new Date()) {
        return reply.status(401).send({ error: 'Session expired' });
      }

      const tournamentId = parseInt(id, 10);
      const tournament = await prisma.tournament.findUnique({
        where: { id: tournamentId },
        include: { _count: { select: { participants: true } } },
      });

      if (!tournament) {
        return reply.status(404).send({ error: 'Tournament not found' });
      }

      if (tournament.status !== 'registration') {
        return reply.status(400).send({ error: 'Registration is not open' });
      }

      if (tournament._count.participants >= tournament.maxParticipants) {
        return reply.status(400).send({ error: 'Tournament is full' });
      }

      // Check rating requirements
      const userRating = session.user.rating;
      if (tournament.minRating && userRating < tournament.minRating) {
        return reply.status(400).send({ error: 'Rating too low' });
      }
      if (tournament.maxRating && userRating > tournament.maxRating) {
        return reply.status(400).send({ error: 'Rating too high' });
      }

      // Register
      await prisma.tournamentParticipant.create({
        data: {
          tournamentId,
          userId: session.userId,
        },
      });

      return reply.send({ success: true });
    } catch (error: any) {
      if (error.code === 'P2002') {
        return reply.status(400).send({ error: 'Already registered' });
      }
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to register' });
    }
  });
}
