import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { prisma } from '../index.js';
import { 
  validateTelegramInitData, 
  generateAuthCode, 
  generateSessionToken 
} from '../utils/telegram.js';

// Validation schemas
const emailCodeSchema = z.object({
  email: z.string().email(),
});

const verifyCodeSchema = z.object({
  email: z.string().email(),
  code: z.string().length(6),
});

export default async function authRoutes(fastify: FastifyInstance) {
  /**
   * POST /api/auth/telegram
   * Authenticate via Telegram WebApp initData
   */
  fastify.post('/telegram', async (request: FastifyRequest, reply: FastifyReply) => {
    const initData = request.headers['x-telegram-init-data'] as string;
    
    if (!initData) {
      return reply.status(400).send({ 
        success: false, 
        message: 'Missing Telegram init data' 
      });
    }

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) {
      fastify.log.error('TELEGRAM_BOT_TOKEN not configured');
      return reply.status(500).send({ 
        success: false, 
        message: 'Server configuration error' 
      });
    }

    // Validate initData
    const telegramData = validateTelegramInitData(initData, botToken);
    
    if (!telegramData || !telegramData.user) {
      return reply.status(401).send({ 
        success: false, 
        message: 'Invalid Telegram authentication' 
      });
    }

    const tgUser = telegramData.user;

    try {
      // Find or create user
      let user = await prisma.user.findUnique({
        where: { telegramId: BigInt(tgUser.id) },
      });

      if (!user) {
        // Create new user
        user = await prisma.user.create({
          data: {
            telegramId: BigInt(tgUser.id),
            firstName: tgUser.first_name,
            lastName: tgUser.last_name,
            username: tgUser.username,
            photoUrl: tgUser.photo_url,
            rating: 1500, // Starting rating
          },
        });

        // Create initial rating history entry
        await prisma.ratingHistory.create({
          data: {
            userId: user.id,
            rating: 1500,
            change: 0,
            reason: 'initial',
          },
        });

        fastify.log.info(`New user created: ${user.id} (Telegram: ${tgUser.id})`);
      } else {
        // Update user info from Telegram
        user = await prisma.user.update({
          where: { id: user.id },
          data: {
            firstName: tgUser.first_name,
            lastName: tgUser.last_name,
            username: tgUser.username,
            photoUrl: tgUser.photo_url,
          },
        });
      }

      // Create session
      const token = generateSessionToken();
      const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days

      await prisma.session.create({
        data: {
          userId: user.id,
          token,
          expiresAt,
        },
      });

      // Return user data
      return reply.send({
        success: true,
        user: {
          id: user.id,
          telegramId: Number(user.telegramId),
          firstName: user.firstName,
          lastName: user.lastName,
          username: user.username,
          photoUrl: user.photoUrl,
          rating: user.rating,
          city: user.city,
          wins: user.wins,
          losses: user.losses,
        },
        token,
      });
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ 
        success: false, 
        message: 'Authentication failed' 
      });
    }
  });

  /**
   * POST /api/auth/email/send-code
   * Send verification code to email
   */
  fastify.post('/email/send-code', async (request: FastifyRequest, reply: FastifyReply) => {
    const body = emailCodeSchema.safeParse(request.body);
    
    if (!body.success) {
      return reply.status(400).send({ 
        success: false, 
        message: 'Invalid email address' 
      });
    }

    const { email } = body.data;

    try {
      // Generate code
      const code = generateAuthCode();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      // Find existing user by email or create auth code record
      const existingUser = await prisma.user.findUnique({
        where: { email },
      });

      // Delete old codes for this email
      await prisma.authCode.deleteMany({
        where: { email },
      });

      // Create new code
      await prisma.authCode.create({
        data: {
          email,
          code,
          expiresAt,
          userId: existingUser?.id,
        },
      });

      // TODO: Send email with code
      // For now, log the code (remove in production!)
      fastify.log.info(`Auth code for ${email}: ${code}`);

      // In production, use nodemailer:
      // await sendEmail(email, 'Код подтверждения', `Ваш код: ${code}`);

      return reply.send({ 
        success: true, 
        message: 'Code sent to email' 
      });
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ 
        success: false, 
        message: 'Failed to send code' 
      });
    }
  });

  /**
   * POST /api/auth/email/verify
   * Verify email code and authenticate
   */
  fastify.post('/email/verify', async (request: FastifyRequest, reply: FastifyReply) => {
    const body = verifyCodeSchema.safeParse(request.body);
    
    if (!body.success) {
      return reply.status(400).send({ 
        success: false, 
        message: 'Invalid email or code' 
      });
    }

    const { email, code } = body.data;

    try {
      // Find valid code
      const authCode = await prisma.authCode.findFirst({
        where: {
          email,
          code,
          used: false,
          expiresAt: { gt: new Date() },
        },
      });

      if (!authCode) {
        return reply.status(400).send({ 
          success: false, 
          message: 'Invalid or expired code' 
        });
      }

      // Mark code as used
      await prisma.authCode.update({
        where: { id: authCode.id },
        data: { used: true },
      });

      // Find or create user
      let user = await prisma.user.findUnique({
        where: { email },
      });

      if (!user) {
        // Create new user with email
        user = await prisma.user.create({
          data: {
            email,
            firstName: email.split('@')[0], // Use email prefix as name
            rating: 1500,
          },
        });

        // Create initial rating history
        await prisma.ratingHistory.create({
          data: {
            userId: user.id,
            rating: 1500,
            change: 0,
            reason: 'initial',
          },
        });

        fastify.log.info(`New user created via email: ${user.id}`);
      }

      // Create session
      const token = generateSessionToken();
      const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

      await prisma.session.create({
        data: {
          userId: user.id,
          token,
          expiresAt,
        },
      });

      return reply.send({
        success: true,
        user: {
          id: user.id,
          telegramId: user.telegramId ? Number(user.telegramId) : undefined,
          firstName: user.firstName,
          lastName: user.lastName,
          username: user.username,
          photoUrl: user.photoUrl,
          rating: user.rating,
          city: user.city,
          wins: user.wins,
          losses: user.losses,
        },
        token,
      });
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ 
        success: false, 
        message: 'Verification failed' 
      });
    }
  });

  /**
   * GET /api/auth/me
   * Get current authenticated user
   */
  fastify.get('/me', async (request: FastifyRequest, reply: FastifyReply) => {
    const token = request.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return reply.status(401).send({ 
        success: false, 
        message: 'Not authenticated' 
      });
    }

    try {
      const session = await prisma.session.findUnique({
        where: { token },
        include: { user: true },
      });

      if (!session || session.expiresAt < new Date()) {
        return reply.status(401).send({ 
          success: false, 
          message: 'Session expired' 
        });
      }

      const user = session.user;

      return reply.send({
        id: user.id,
        telegramId: user.telegramId ? Number(user.telegramId) : undefined,
        firstName: user.firstName,
        lastName: user.lastName,
        username: user.username,
        photoUrl: user.photoUrl,
        rating: user.rating,
        city: user.city,
        wins: user.wins,
        losses: user.losses,
      });
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ 
        success: false, 
        message: 'Failed to get user' 
      });
    }
  });

  /**
   * POST /api/auth/logout
   * Logout and invalidate session
   */
  fastify.post('/logout', async (request: FastifyRequest, reply: FastifyReply) => {
    const token = request.headers.authorization?.replace('Bearer ', '');
    
    if (token) {
      await prisma.session.deleteMany({
        where: { token },
      });
    }

    return reply.send({ success: true });
  });
}
