import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { prisma } from '../index.js';

const createRequestSchema = z.object({
  courtId: z.number().int().positive().optional(),
  date: z.string(),
  time: z.string(),
  duration: z.number().int().min(30).max(180).default(60),
  minLevel: z.number().int().min(0).max(3000).default(1000),
  maxLevel: z.number().int().min(0).max(3000).default(2000),
  comment: z.string().max(500).optional(),
});

export default async function playRequestRoutes(fastify: FastifyInstance) {
  /**
   * GET /api/play-requests
   * Get active play requests
   */
  fastify.get('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const { date, courtId, limit = '20', offset = '0' } = request.query as any;

    try {
      const where: any = { status: 'active' };
      
      if (date) {
        const startDate = new Date(date);
        const endDate = new Date(date);
        endDate.setDate(endDate.getDate() + 1);
        where.date = { gte: startDate, lt: endDate };
      }
      
      if (courtId) {
        where.courtId = parseInt(courtId, 10);
      }

      const [requests, total] = await Promise.all([
        prisma.playRequest.findMany({
          where,
          orderBy: { date: 'asc' },
          take: parseInt(limit, 10),
          skip: parseInt(offset, 10),
          include: {
            user: { 
              select: { 
                id: true, 
                firstName: true, 
                lastName: true, 
                rating: true, 
                photoUrl: true 
              } 
            },
            court: { select: { id: true, name: true, address: true } },
          },
        }),
        prisma.playRequest.count({ where }),
      ]);

      return reply.send({ requests, total });
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to get requests' });
    }
  });

  /**
   * POST /api/play-requests
   * Create a new play request
   */
  fastify.post('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const token = request.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return reply.status(401).send({ error: 'Not authenticated' });
    }

    const body = createRequestSchema.safeParse(request.body);
    if (!body.success) {
      return reply.status(400).send({ error: 'Invalid data', details: body.error.errors });
    }

    try {
      const session = await prisma.session.findUnique({
        where: { token },
      });

      if (!session || session.expiresAt < new Date()) {
        return reply.status(401).send({ error: 'Session expired' });
      }

      const playRequest = await prisma.playRequest.create({
        data: {
          userId: session.userId,
          ...body.data,
          date: new Date(body.data.date),
        },
        include: {
          user: { select: { id: true, firstName: true, lastName: true, rating: true } },
          court: { select: { id: true, name: true } },
        },
      });

      return reply.status(201).send(playRequest);
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to create request' });
    }
  });

  /**
   * POST /api/play-requests/:id/respond
   * Respond to a play request
   */
  fastify.post('/:id/respond', async (request: FastifyRequest, reply: FastifyReply) => {
    const token = request.headers.authorization?.replace('Bearer ', '');
    const { id } = request.params as { id: string };
    
    if (!token) {
      return reply.status(401).send({ error: 'Not authenticated' });
    }

    try {
      const session = await prisma.session.findUnique({
        where: { token },
      });

      if (!session || session.expiresAt < new Date()) {
        return reply.status(401).send({ error: 'Session expired' });
      }

      const requestId = parseInt(id, 10);

      // Check if request exists and is active
      const playRequest = await prisma.playRequest.findUnique({
        where: { id: requestId },
      });

      if (!playRequest) {
        return reply.status(404).send({ error: 'Request not found' });
      }

      if (playRequest.status !== 'active') {
        return reply.status(400).send({ error: 'Request is no longer active' });
      }

      if (playRequest.userId === session.userId) {
        return reply.status(400).send({ error: 'Cannot respond to your own request' });
      }

      // Create or update response
      await prisma.playResponse.upsert({
        where: {
          requestId_userId: {
            requestId,
            userId: session.userId,
          },
        },
        create: {
          requestId,
          userId: session.userId,
          status: 'pending',
        },
        update: {
          status: 'pending',
        },
      });

      return reply.send({ success: true });
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to respond' });
    }
  });

  /**
   * DELETE /api/play-requests/:id
   * Cancel own play request
   */
  fastify.delete('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const token = request.headers.authorization?.replace('Bearer ', '');
    const { id } = request.params as { id: string };
    
    if (!token) {
      return reply.status(401).send({ error: 'Not authenticated' });
    }

    try {
      const session = await prisma.session.findUnique({
        where: { token },
      });

      if (!session || session.expiresAt < new Date()) {
        return reply.status(401).send({ error: 'Session expired' });
      }

      const requestId = parseInt(id, 10);

      const playRequest = await prisma.playRequest.findUnique({
        where: { id: requestId },
      });

      if (!playRequest) {
        return reply.status(404).send({ error: 'Request not found' });
      }

      if (playRequest.userId !== session.userId) {
        return reply.status(403).send({ error: 'Not your request' });
      }

      await prisma.playRequest.update({
        where: { id: requestId },
        data: { status: 'cancelled' },
      });

      return reply.send({ success: true });
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to cancel request' });
    }
  });
}
