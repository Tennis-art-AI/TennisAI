import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { prisma } from '../index.js';

const createGameSchema = z.object({
  opponentId: z.number().int().positive(),
  score: z.string().min(1),
  winnerId: z.number().int().positive(),
  courtId: z.number().int().positive().optional(),
  playedAt: z.string().datetime(),
});

export default async function gameRoutes(fastify: FastifyInstance) {
  /**
   * POST /api/games
   * Create a new game
   */
  fastify.post('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const token = request.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return reply.status(401).send({ error: 'Not authenticated' });
    }

    const body = createGameSchema.safeParse(request.body);
    if (!body.success) {
      return reply.status(400).send({ error: 'Invalid data', details: body.error.errors });
    }

    try {
      const session = await prisma.session.findUnique({
        where: { token },
        include: { user: true },
      });

      if (!session || session.expiresAt < new Date()) {
        return reply.status(401).send({ error: 'Session expired' });
      }

      const { opponentId, score, winnerId, courtId, playedAt } = body.data;
      const userId = session.userId;

      // Validate winnerId
      if (winnerId !== userId && winnerId !== opponentId) {
        return reply.status(400).send({ error: 'Winner must be one of the players' });
      }

      // Create game
      const game = await prisma.game.create({
        data: {
          player1Id: userId,
          player2Id: opponentId,
          winnerId,
          score,
          courtId,
          playedAt: new Date(playedAt),
        },
        include: {
          player1: { select: { id: true, firstName: true, lastName: true } },
          player2: { select: { id: true, firstName: true, lastName: true } },
        },
      });

      // Update win/loss counts
      const loserId = winnerId === userId ? opponentId : userId;
      
      await prisma.user.update({
        where: { id: winnerId },
        data: { wins: { increment: 1 } },
      });

      await prisma.user.update({
        where: { id: loserId },
        data: { losses: { increment: 1 } },
      });

      // TODO: Update ratings based on ELO system

      return reply.status(201).send(game);
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to create game' });
    }
  });

  /**
   * GET /api/games/:id
   * Get game by ID
   */
  fastify.get('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };

    try {
      const game = await prisma.game.findUnique({
        where: { id: parseInt(id, 10) },
        include: {
          player1: { select: { id: true, firstName: true, lastName: true, rating: true } },
          player2: { select: { id: true, firstName: true, lastName: true, rating: true } },
          court: true,
        },
      });

      if (!game) {
        return reply.status(404).send({ error: 'Game not found' });
      }

      return reply.send(game);
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to get game' });
    }
  });
}
