import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../index.js';

export default async function courtRoutes(fastify: FastifyInstance) {
  /**
   * GET /api/courts
   * Get courts list
   */
  fastify.get('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const { city, type, isPaid, limit = '50', offset = '0' } = request.query as any;

    try {
      const where: any = { isActive: true };
      
      if (city) where.city = { contains: city, mode: 'insensitive' };
      if (type) where.type = type;
      if (isPaid !== undefined) where.isPaid = isPaid === 'true';

      const [courts, total] = await Promise.all([
        prisma.court.findMany({
          where,
          orderBy: { name: 'asc' },
          take: parseInt(limit, 10),
          skip: parseInt(offset, 10),
        }),
        prisma.court.count({ where }),
      ]);

      return reply.send({ courts, total });
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to get courts' });
    }
  });

  /**
   * GET /api/courts/:id
   * Get court by ID
   */
  fastify.get('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };

    try {
      const court = await prisma.court.findUnique({
        where: { id: parseInt(id, 10) },
      });

      if (!court) {
        return reply.status(404).send({ error: 'Court not found' });
      }

      return reply.send(court);
    } catch (error) {
      fastify.log.error(error);
      return reply.status(500).send({ error: 'Failed to get court' });
    }
  });
}
