
  # Minimalist Telegram Mini App

  This is a code bundle for Minimalist Telegram Mini App. The original project is available at https://www.figma.com/design/V7M19agJymSBcvailgdtv5/Minimalist-Telegram-Mini-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  