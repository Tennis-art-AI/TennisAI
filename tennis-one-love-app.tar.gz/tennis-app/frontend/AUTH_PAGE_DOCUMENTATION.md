# Tennis One Love - Страница Авторизации

## 📱 Финальный макет для разработки

**Дата создания:** 23 января 2026  
**Размер экрана:** 393×852 пикселя (Telegram Mini App)  
**Технологии:** React + TypeScript + Tailwind CSS

---

## 🎨 Описание макета

Минималистичная страница авторизации для теннисного приложения с темной цветовой схемой.

### Структура (сверху вниз):

1. **Заголовок** - "Tennis one love"
   - Цвет: белый
   - Размер: text-4xl (36px)
   - Вес: font-bold (700)
   - Позиция: вверху с отступом mt-8

2. **Подзаголовок** - "Выбери способ авторизации"
   - Цвет: белый с прозрачностью (white/95)
   - Размер: text-base (16px)
   - Вес: font-medium (500)

3. **Кнопка Telegram**
   - Цвет фона: #0088cc (синий Telegram)
   - Hover: #0077b3
   - Иконка: SVG логотип Telegram
   - Текст: "Войти через Telegram"

4. **Поле Email**
   - Label: "Ввести E-mail" (text-xs, white/80)
   - Background: белый с прозрачностью (white/15)
   - Border: white/30
   - Focus border: lime-400
   - Placeholder: "tennis@gmail.com"

5. **Кнопка авторизации**
   - Цвет фона: lime-500 (яркий салатовый)
   - Hover: lime-600
   - Вес текста: font-semibold (600)
   - Текст: "Авторизоваться"

6. **Футер**
   - Позиция: внизу экрана (pb-6)
   - Текст: "Входя в приложение, вы соглашаетесь с условиями использования"
   - Цвет: white/60
   - Ссылка: lime-400

---

## 🎯 Дизайн-система

### Цветовая палитра:
```css
/* Основные цвета */
--telegram-blue: #0088cc
--telegram-blue-hover: #0077b3
--lime-green: rgb(132, 204, 22) /* lime-500 */
--lime-green-hover: rgb(101, 163, 13) /* lime-600 */
--lime-accent: rgb(163, 230, 53) /* lime-400 */

/* Фон и оверлеи */
--bg-dark: #1a1a1a
--overlay-top: rgba(0, 0, 0, 0.6)
--overlay-middle: rgba(0, 0, 0, 0.25)
--overlay-bottom: rgba(0, 0, 0, 0.6)

/* Прозрачности */
--white-15: rgba(255, 255, 255, 0.15)
--white-30: rgba(255, 255, 255, 0.3)
--white-60: rgba(255, 255, 255, 0.6)
--white-80: rgba(255, 255, 255, 0.8)
--white-95: rgba(255, 255, 255, 0.95)
```

### Отступы и размеры:
```css
/* Контейнер */
width: 393px
height: 852px
padding: 24px (px-6 py-6)

/* Кнопки */
padding-y: 16px (py-4)
border-radius: 8px (rounded-lg)
gap: 12px (gap-3)

/* Формы */
space-y: 20px (space-y-5)
```

### Типографика:
```css
/* Заголовок */
font-size: 36px (text-4xl)
font-weight: 700 (font-bold)
letter-spacing: 0.025em (tracking-wide)

/* Подзаголовок */
font-size: 16px (text-base)
font-weight: 500 (font-medium)

/* Кнопки */
font-weight: 500 (font-medium) - Telegram
font-weight: 600 (font-semibold) - Авторизация

/* Футер */
font-size: 12px (text-xs)
```

---

## 📁 Файлы для разработки

### Основной компонент:
```
/src/app/components/auth-page-final.tsx
```

### Зависимости:
- Фоновое изображение: `figma:asset/fcb844ec7ee47b19ad88b3926c0b6ef98317e729.png`
- React (useState для управления состоянием)
- Tailwind CSS v4.0

### Пример использования:
```tsx
import { AuthPageFinal } from '@/app/components/auth-page-final';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  if (!isAuthenticated) {
    return <AuthPageFinal onAuthComplete={() => setIsAuthenticated(true)} />;
  }

  return <MainApp />;
}
```

---

## 🔧 Технические детали

### Layout структура:
```
<div style={{ width: '393px', height: '852px' }}>
  ├── Фоновое изображение (absolute)
  ├── Градиентный оверлей (absolute)
  └── Контент (relative, flex-col, justify-between)
      ├── Заголовок (mt-8)
      ├── Форма авторизации (w-full, space-y-5)
      └── Футер (pb-6)
</div>
```

### Градиент оверлея:
```css
background: linear-gradient(
  to bottom,
  rgba(0, 0, 0, 0.6) 0%,
  rgba(0, 0, 0, 0.25) 50%,
  rgba(0, 0, 0, 0.6) 100%
);
```

### SVG иконка Telegram:
- Размер: 22×22px
- viewBox: 0 0 24 24
- Fill: currentColor (наследует цвет текста)

---

## 🎭 Интерактивность

### Hover-эффекты:
1. **Кнопка Telegram**: `#0088cc` → `#0077b3`
2. **Кнопка Авторизации**: `lime-500` → `lime-600`
3. **Ссылка условий**: `lime-400` → `lime-300`

### Focus-эффекты (поле Email):
- Border: `white/30` → `lime-400`
- Background: `white/15` → `white/20`
- Outline: none

### Transitions:
```css
transition: colors /* для всех интерактивных элементов */
transition: all /* для поля email */
```

---

## ✅ Чек-лист для разработки

### Обязательно реализовать:
- [ ] Точный размер 393×852px
- [ ] Фоновое изображение теннисного корта
- [ ] Градиентный оверлей с тремя точками
- [ ] Все hover и focus состояния
- [ ] SVG иконка Telegram
- [ ] Адаптивная типографика
- [ ] Тени (drop-shadow, shadow-xl, shadow-lg)
- [ ] Backdrop-blur для поля email

### Функциональность:
- [ ] Обработчик onClick для кнопки Telegram
- [ ] Обработчик onClick для кнопки Авторизации
- [ ] Валидация email (опционально)
- [ ] Обработка состояния загрузки (опционально)
- [ ] Обработка ошибок (опционально)

### Доступность:
- [ ] Label для поля email
- [ ] Placeholder для email
- [ ] Правильный type="email"
- [ ] Tab navigation
- [ ] Keyboard accessibility

---

## 📸 Скриншот макета

См. скриншот финального макета в приложении.

---

## 🚀 Готово к разработке

Этот макет полностью готов для передачи в Claude Code или другим разработчикам.

**Файл компонента:** `/src/app/components/auth-page-final.tsx`

**Контакты для вопросов:** Tennis One Love Team

---

*Документация создана автоматически в Figma Make*
*Дата: 23 января 2026*
