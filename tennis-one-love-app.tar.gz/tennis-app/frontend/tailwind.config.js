/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Цвета из макета
        primary: '#84cc16', // lime-500
        background: '#1a1a1a',
        card: '#2a2a2a',
        // Telegram theme colors
        'tg-bg': 'var(--tg-theme-bg-color, #1a1a1a)',
        'tg-text': 'var(--tg-theme-text-color, #ffffff)',
        'tg-hint': 'var(--tg-theme-hint-color, #6b7280)',
        'tg-link': 'var(--tg-theme-link-color, #84cc16)',
        'tg-button': 'var(--tg-theme-button-color, #84cc16)',
        'tg-button-text': 'var(--tg-theme-button-text-color, #ffffff)',
        'tg-secondary-bg': 'var(--tg-theme-secondary-bg-color, #2a2a2a)',
      },
      fontFamily: {
        sans: ['-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
