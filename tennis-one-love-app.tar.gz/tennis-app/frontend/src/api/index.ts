import axios, { AxiosInstance, AxiosError } from 'axios';

// API URL - в production будет тот же домен
const API_URL = import.meta.env.VITE_API_URL || '/api';

// Создаём axios instance
const api: AxiosInstance = axios.create({
  baseURL: API_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor для добавления Telegram initData в каждый запрос
api.interceptors.request.use((config) => {
  const tg = window.Telegram?.WebApp;
  
  if (tg?.initData) {
    config.headers['X-Telegram-Init-Data'] = tg.initData;
  }
  
  return config;
});

// Interceptor для обработки ошибок
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      // Неавторизован - возможно, initData невалидный
      console.error('Unauthorized - invalid initData');
    }
    
    if (error.response?.status === 403) {
      // Доступ запрещён
      console.error('Forbidden');
    }
    
    if (error.response?.status === 500) {
      // Ошибка сервера
      console.error('Server error');
    }
    
    return Promise.reject(error);
  }
);

// ============ AUTH API ============

export interface AuthResponse {
  success: boolean;
  user: {
    id: number;
    telegramId: number;
    firstName: string;
    lastName?: string;
    username?: string;
    photoUrl?: string;
    rating: number;
    city?: string;
  };
  token: string;
}

export const authApi = {
  // Авторизация через Telegram
  loginTelegram: async (): Promise<AuthResponse> => {
    const response = await api.post<AuthResponse>('/auth/telegram');
    return response.data;
  },
  
  // Авторизация через Email (отправка кода)
  sendEmailCode: async (email: string): Promise<{ success: boolean }> => {
    const response = await api.post('/auth/email/send-code', { email });
    return response.data;
  },
  
  // Авторизация через Email (проверка кода)
  verifyEmailCode: async (email: string, code: string): Promise<AuthResponse> => {
    const response = await api.post<AuthResponse>('/auth/email/verify', { email, code });
    return response.data;
  },
  
  // Получить текущего пользователя
  getMe: async (): Promise<AuthResponse['user']> => {
    const response = await api.get<AuthResponse['user']>('/auth/me');
    return response.data;
  },
};

// ============ USER API ============

export interface User {
  id: number;
  telegramId?: number;
  firstName: string;
  lastName?: string;
  username?: string;
  photoUrl?: string;
  rating: number;
  city?: string;
  wins: number;
  losses: number;
  createdAt: string;
}

export interface UpdateProfileData {
  firstName?: string;
  lastName?: string;
  city?: string;
  photoUrl?: string;
}

export const userApi = {
  // Получить профиль пользователя
  getProfile: async (userId: number): Promise<User> => {
    const response = await api.get<User>(`/users/${userId}`);
    return response.data;
  },
  
  // Обновить свой профиль
  updateProfile: async (data: UpdateProfileData): Promise<User> => {
    const response = await api.patch<User>('/users/me', data);
    return response.data;
  },
  
  // Получить рейтинг игроков
  getRating: async (params?: { limit?: number; offset?: number; search?: string }): Promise<{ users: User[]; total: number }> => {
    const response = await api.get('/users/rating', { params });
    return response.data;
  },
  
  // Получить историю рейтинга пользователя
  getRatingHistory: async (userId: number): Promise<{ date: string; rating: number }[]> => {
    const response = await api.get(`/users/${userId}/rating-history`);
    return response.data;
  },
};

// ============ GAMES API ============

export interface Game {
  id: number;
  player1Id: number;
  player2Id: number;
  player1: User;
  player2: User;
  score: string;
  winnerId: number;
  courtId?: number;
  court?: Court;
  playedAt: string;
  createdAt: string;
}

export interface CreateGameData {
  opponentId: number;
  score: string;
  winnerId: number;
  courtId?: number;
  playedAt: string;
}

export const gamesApi = {
  // Получить список игр пользователя
  getUserGames: async (userId: number, params?: { limit?: number; offset?: number }): Promise<{ games: Game[]; total: number }> => {
    const response = await api.get(`/users/${userId}/games`, { params });
    return response.data;
  },
  
  // Создать новую игру
  createGame: async (data: CreateGameData): Promise<Game> => {
    const response = await api.post<Game>('/games', data);
    return response.data;
  },
  
  // Получить статистику игр
  getStats: async (userId: number): Promise<{ wins: number; losses: number; winRate: number; totalGames: number }> => {
    const response = await api.get(`/users/${userId}/stats`);
    return response.data;
  },
};

// ============ PLAY REQUESTS API ============

export interface PlayRequest {
  id: number;
  userId: number;
  user: User;
  courtId?: number;
  court?: Court;
  date: string;
  time: string;
  duration: number;
  minLevel: number;
  maxLevel: number;
  comment?: string;
  status: 'active' | 'matched' | 'cancelled';
  createdAt: string;
}

export interface CreatePlayRequestData {
  courtId?: number;
  date: string;
  time: string;
  duration: number;
  minLevel: number;
  maxLevel: number;
  comment?: string;
}

export const playRequestsApi = {
  // Получить активные заявки
  getActiveRequests: async (params?: { date?: string; courtId?: number }): Promise<{ requests: PlayRequest[]; total: number }> => {
    const response = await api.get('/play-requests', { params });
    return response.data;
  },
  
  // Создать заявку на игру
  createRequest: async (data: CreatePlayRequestData): Promise<PlayRequest> => {
    const response = await api.post<PlayRequest>('/play-requests', data);
    return response.data;
  },
  
  // Откликнуться на заявку
  respondToRequest: async (requestId: number): Promise<{ success: boolean }> => {
    const response = await api.post(`/play-requests/${requestId}/respond`);
    return response.data;
  },
  
  // Отменить свою заявку
  cancelRequest: async (requestId: number): Promise<{ success: boolean }> => {
    const response = await api.delete(`/play-requests/${requestId}`);
    return response.data;
  },
};

// ============ COURTS API ============

export interface Court {
  id: number;
  name: string;
  address: string;
  city: string;
  latitude?: number;
  longitude?: number;
  type: 'indoor' | 'outdoor';
  surface: 'hard' | 'clay' | 'grass' | 'carpet';
  isPaid: boolean;
  pricePerHour?: number;
  phone?: string;
  website?: string;
  workingHours?: string;
  createdAt: string;
}

export const courtsApi = {
  // Получить список кортов
  getCourts: async (params?: { city?: string; type?: string; isPaid?: boolean }): Promise<{ courts: Court[]; total: number }> => {
    const response = await api.get('/courts', { params });
    return response.data;
  },
  
  // Получить корт по ID
  getCourt: async (courtId: number): Promise<Court> => {
    const response = await api.get<Court>(`/courts/${courtId}`);
    return response.data;
  },
};

// ============ TOURNAMENTS API ============

export interface Tournament {
  id: number;
  name: string;
  description?: string;
  courtId?: number;
  court?: Court;
  startDate: string;
  endDate: string;
  maxParticipants: number;
  currentParticipants: number;
  minRating?: number;
  maxRating?: number;
  entryFee?: number;
  prizePool?: string;
  status: 'upcoming' | 'registration' | 'ongoing' | 'finished';
  createdAt: string;
}

export const tournamentsApi = {
  // Получить список турниров
  getTournaments: async (params?: { status?: string }): Promise<{ tournaments: Tournament[]; total: number }> => {
    const response = await api.get('/tournaments', { params });
    return response.data;
  },
  
  // Зарегистрироваться на турнир
  register: async (tournamentId: number): Promise<{ success: boolean }> => {
    const response = await api.post(`/tournaments/${tournamentId}/register`);
    return response.data;
  },
};

export default api;
