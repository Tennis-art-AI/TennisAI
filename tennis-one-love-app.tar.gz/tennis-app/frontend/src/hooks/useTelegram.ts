import { useCallback, useEffect, useMemo } from 'react';
import type { TelegramWebApp, WebAppUser, ThemeParams } from '@/types/telegram';

/**
 * Хук для работы с Telegram Web Apps API
 */
export function useTelegram() {
  const tg: TelegramWebApp | undefined = window.Telegram?.WebApp;

  // Инициализация при монтировании
  useEffect(() => {
    if (tg) {
      // Сообщаем Telegram, что приложение готово
      tg.ready();
      
      // Разворачиваем на весь экран
      tg.expand();
      
      // Устанавливаем цвета под нашу тему
      tg.setHeaderColor('#1a1a1a');
      tg.setBackgroundColor('#1a1a1a');
    }
  }, [tg]);

  // Данные пользователя
  const user: WebAppUser | undefined = useMemo(() => {
    return tg?.initDataUnsafe?.user;
  }, [tg]);

  // Тема (светлая/тёмная)
  const colorScheme = useMemo(() => {
    return tg?.colorScheme || 'dark';
  }, [tg]);

  // Параметры темы
  const themeParams: ThemeParams | undefined = useMemo(() => {
    return tg?.themeParams;
  }, [tg]);

  // initData для отправки на бэкенд (для валидации)
  const initData = useMemo(() => {
    return tg?.initData || '';
  }, [tg]);

  // Платформа (ios, android, web, etc.)
  const platform = useMemo(() => {
    return tg?.platform || 'unknown';
  }, [tg]);

  // Haptic Feedback - вибрация при нажатии
  const hapticFeedback = useCallback((type: 'light' | 'medium' | 'heavy' | 'success' | 'error' | 'warning' | 'selection') => {
    if (!tg?.HapticFeedback) return;
    
    switch (type) {
      case 'light':
      case 'medium':
      case 'heavy':
        tg.HapticFeedback.impactOccurred(type);
        break;
      case 'success':
      case 'error':
      case 'warning':
        tg.HapticFeedback.notificationOccurred(type);
        break;
      case 'selection':
        tg.HapticFeedback.selectionChanged();
        break;
    }
  }, [tg]);

  // Показать главную кнопку
  const showMainButton = useCallback((text: string, onClick: () => void) => {
    if (!tg?.MainButton) return;
    
    tg.MainButton.setText(text);
    tg.MainButton.onClick(onClick);
    tg.MainButton.show();
  }, [tg]);

  // Скрыть главную кнопку
  const hideMainButton = useCallback(() => {
    if (!tg?.MainButton) return;
    tg.MainButton.hide();
  }, [tg]);

  // Показать кнопку "Назад"
  const showBackButton = useCallback((onClick: () => void) => {
    if (!tg?.BackButton) return;
    
    tg.BackButton.onClick(onClick);
    tg.BackButton.show();
  }, [tg]);

  // Скрыть кнопку "Назад"
  const hideBackButton = useCallback(() => {
    if (!tg?.BackButton) return;
    tg.BackButton.hide();
  }, [tg]);

  // Показать popup
  const showPopup = useCallback((message: string, title?: string, buttons?: Array<{ id: string; text: string; type?: 'default' | 'destructive' }>) => {
    return new Promise<string>((resolve) => {
      if (!tg) {
        // Fallback для браузера
        alert(message);
        resolve('ok');
        return;
      }
      
      tg.showPopup({
        title,
        message,
        buttons: buttons || [{ type: 'ok' }],
      }, (buttonId) => {
        resolve(buttonId || 'ok');
      });
    });
  }, [tg]);

  // Показать alert
  const showAlert = useCallback((message: string) => {
    return new Promise<void>((resolve) => {
      if (!tg) {
        alert(message);
        resolve();
        return;
      }
      
      tg.showAlert(message, () => resolve());
    });
  }, [tg]);

  // Показать confirm
  const showConfirm = useCallback((message: string) => {
    return new Promise<boolean>((resolve) => {
      if (!tg) {
        resolve(confirm(message));
        return;
      }
      
      tg.showConfirm(message, (confirmed) => resolve(confirmed));
    });
  }, [tg]);

  // Закрыть приложение
  const close = useCallback(() => {
    if (tg) {
      tg.close();
    }
  }, [tg]);

  // Открыть ссылку
  const openLink = useCallback((url: string, tryInstantView = false) => {
    if (tg) {
      tg.openLink(url, { try_instant_view: tryInstantView });
    } else {
      window.open(url, '_blank');
    }
  }, [tg]);

  // Открыть Telegram ссылку (например, на канал или пользователя)
  const openTelegramLink = useCallback((url: string) => {
    if (tg) {
      tg.openTelegramLink(url);
    } else {
      window.open(url, '_blank');
    }
  }, [tg]);

  // Проверка, запущено ли приложение в Telegram
  const isTelegramApp = useMemo(() => {
    return !!tg && !!tg.initData;
  }, [tg]);

  return {
    tg,
    user,
    colorScheme,
    themeParams,
    initData,
    platform,
    isTelegramApp,
    hapticFeedback,
    showMainButton,
    hideMainButton,
    showBackButton,
    hideBackButton,
    showPopup,
    showAlert,
    showConfirm,
    close,
    openLink,
    openTelegramLink,
  };
}
