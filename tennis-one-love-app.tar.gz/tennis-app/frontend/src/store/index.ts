import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User } from '@/api';

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  
  // Actions
  setUser: (user: User | null) => void;
  setToken: (token: string | null) => void;
  login: (user: User, token: string) => void;
  logout: () => void;
  setLoading: (loading: boolean) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: true,
      
      setUser: (user) => set({ user, isAuthenticated: !!user }),
      
      setToken: (token) => set({ token }),
      
      login: (user, token) => set({ 
        user, 
        token, 
        isAuthenticated: true, 
        isLoading: false 
      }),
      
      logout: () => set({ 
        user: null, 
        token: null, 
        isAuthenticated: false 
      }),
      
      setLoading: (isLoading) => set({ isLoading }),
    }),
    {
      name: 'tennis-auth-storage',
      partialize: (state) => ({ 
        token: state.token,
        // Не сохраняем user в localStorage - получим с сервера при старте
      }),
    }
  )
);

// ============ APP STATE ============

type Tab = 'rating' | 'profile' | 'play' | 'courts' | 'home';

interface AppState {
  activeTab: Tab;
  showSettings: boolean;
  
  // Actions
  setActiveTab: (tab: Tab) => void;
  setShowSettings: (show: boolean) => void;
}

export const useAppStore = create<AppState>()((set) => ({
  activeTab: 'home',
  showSettings: false,
  
  setActiveTab: (activeTab) => set({ activeTab, showSettings: false }),
  setShowSettings: (showSettings) => set({ showSettings }),
}));

// ============ UI STATE ============

interface UIState {
  isModalOpen: boolean;
  modalContent: React.ReactNode | null;
  isBottomSheetOpen: boolean;
  bottomSheetContent: React.ReactNode | null;
  toasts: Array<{
    id: string;
    type: 'success' | 'error' | 'info' | 'warning';
    message: string;
  }>;
  
  // Actions
  openModal: (content: React.ReactNode) => void;
  closeModal: () => void;
  openBottomSheet: (content: React.ReactNode) => void;
  closeBottomSheet: () => void;
  addToast: (type: 'success' | 'error' | 'info' | 'warning', message: string) => void;
  removeToast: (id: string) => void;
}

export const useUIStore = create<UIState>()((set) => ({
  isModalOpen: false,
  modalContent: null,
  isBottomSheetOpen: false,
  bottomSheetContent: null,
  toasts: [],
  
  openModal: (modalContent) => set({ isModalOpen: true, modalContent }),
  closeModal: () => set({ isModalOpen: false, modalContent: null }),
  
  openBottomSheet: (bottomSheetContent) => set({ isBottomSheetOpen: true, bottomSheetContent }),
  closeBottomSheet: () => set({ isBottomSheetOpen: false, bottomSheetContent: null }),
  
  addToast: (type, message) => set((state) => ({
    toasts: [...state.toasts, { 
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`, 
      type, 
      message 
    }],
  })),
  
  removeToast: (id) => set((state) => ({
    toasts: state.toasts.filter((toast) => toast.id !== id),
  })),
}));
