import { useEffect, useState } from 'react';
import { useTelegram } from '@/hooks/useTelegram';
import { useAuthStore, useAppStore } from '@/store';
import { authApi } from '@/api';
import { BottomNavigation } from '@/app/components/bottom-navigation';
import { ProfilePage, RatingPage, PlayPage, CourtsPage, HomePage } from '@/app/components/placeholder-pages';
import { AuthPage } from '@/app/components/auth-page';
import { SettingsPage } from '@/app/components/settings-page';
import { Modal } from '@/app/components/modal';

// Sentry для отслеживания ошибок
import * as Sentry from '@sentry/react';

// Инициализация Sentry
if (import.meta.env.VITE_SENTRY_DSN) {
  Sentry.init({
    dsn: import.meta.env.VITE_SENTRY_DSN,
    environment: import.meta.env.MODE,
    tracesSampleRate: 1.0,
  });
}

export default function App() {
  const { user, isTelegramApp, initData, hapticFeedback, colorScheme } = useTelegram();
  const { isAuthenticated, isLoading, login, setLoading } = useAuthStore();
  const { activeTab, setActiveTab, showSettings, setShowSettings } = useAppStore();
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Автоматическая авторизация через Telegram при запуске
  useEffect(() => {
    const authenticateUser = async () => {
      // Если уже авторизован, пропускаем
      if (isAuthenticated) {
        setLoading(false);
        return;
      }

      // Если запущено в Telegram и есть initData
      if (isTelegramApp && initData) {
        try {
          const response = await authApi.loginTelegram();
          if (response.success) {
            login(response.user, response.token);
            hapticFeedback('success');
          }
        } catch (error) {
          console.error('Telegram auth failed:', error);
          setAuthError('Ошибка авторизации через Telegram');
          setLoading(false);
        }
      } else {
        // Не в Telegram - показываем форму авторизации
        setLoading(false);
      }
    };

    authenticateUser();
  }, [isTelegramApp, initData]);

  // Хук для haptic feedback при смене вкладки
  const handleTabChange = (tab: string) => {
    hapticFeedback('selection');
    setActiveTab(tab as any);
  };

  // Рендер текущей страницы
  const renderPage = () => {
    if (showSettings) {
      return <SettingsPage onBack={() => setShowSettings(false)} />;
    }
    
    switch (activeTab) {
      case 'profile':
        return <ProfilePage />;
      case 'rating':
        return <RatingPage />;
      case 'play':
        return <PlayPage />;
      case 'courts':
        return <CourtsPage />;
      case 'home':
        return (
          <HomePage 
            onUploadPhoto={() => {
              hapticFeedback('light');
              setShowPhotoModal(true);
            }} 
            onOpenSettings={() => {
              hapticFeedback('light');
              setShowSettings(true);
            }} 
          />
        );
      default:
        return (
          <HomePage 
            onUploadPhoto={() => setShowPhotoModal(true)} 
            onOpenSettings={() => setShowSettings(true)} 
          />
        );
    }
  };

  // Показываем loader пока идёт автоматическая авторизация
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#1a1a1a]">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-lime-400 via-lime-500 to-lime-600 animate-pulse" />
          <p className="text-gray-400 text-sm">Загрузка...</p>
        </div>
      </div>
    );
  }

  // Показываем страницу авторизации если не авторизован
  if (!isAuthenticated) {
    return (
      <AuthPage 
        onAuthComplete={(userData, token) => {
          login(userData, token);
          hapticFeedback('success');
        }}
        error={authError}
        isTelegramApp={isTelegramApp}
      />
    );
  }

  // Основное приложение
  return (
    <div 
      className={`min-h-screen flex items-center justify-center ${
        colorScheme === 'dark' ? 'bg-[#0a0a0a]' : 'bg-gray-100'
      }`}
    >
      {/* Фиксированный контейнер 393×852 */}
      <div className="w-[393px] h-[852px] bg-[#1a1a1a] flex flex-col overflow-hidden relative rounded-3xl shadow-2xl">
        {/* Контент страницы */}
        {renderPage()}
        
        {/* Нижняя навигация */}
        <BottomNavigation 
          activeTab={activeTab} 
          onTabChange={handleTabChange} 
        />
        
        {/* Модальное окно загрузки фото */}
        <Modal isOpen={showPhotoModal} onClose={() => setShowPhotoModal(false)}>
          <div className="text-center pt-8 pb-4">
            <div className="text-4xl mb-4">📷</div>
            <p className="text-white text-base font-medium mb-4">
              Загрузить фото в профиль
            </p>
            <div className="space-y-3">
              <button 
                onClick={() => {
                  hapticFeedback('light');
                  // TODO: Implement photo upload from camera
                  setShowPhotoModal(false);
                }}
                className="w-full bg-lime-500 hover:bg-lime-600 text-white py-3 rounded-lg font-medium transition-colors"
              >
                📸 Сделать фото
              </button>
              <button 
                onClick={() => {
                  hapticFeedback('light');
                  // TODO: Implement photo upload from gallery
                  setShowPhotoModal(false);
                }}
                className="w-full bg-[#2a2a2a] hover:bg-[#333333] text-white py-3 rounded-lg font-medium transition-colors"
              >
                🖼️ Выбрать из галереи
              </button>
            </div>
          </div>
        </Modal>
      </div>
    </div>
  );
}
