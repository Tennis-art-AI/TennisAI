import axios from 'axios';

// Базовый URL API
const API_URL = import.meta.env.VITE_API_URL || '/api';

// Создаём экземпляр axios с базовыми настройками
export const api = axios.create({
  baseURL: API_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Интерцептор запросов - добавляем initData для Telegram
api.interceptors.request.use(
  (config) => {
    // Добавляем Telegram initData в заголовки если доступен
    const initData = window.Telegram?.WebApp?.initData;
    if (initData) {
      config.headers['X-Telegram-Init-Data'] = initData;
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Интерцептор ответов - обработка ошибок
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Обработка различных типов ошибок
    if (error.response) {
      const { status, data } = error.response;
      
      switch (status) {
        case 401:
          // Неавторизован - очищаем токен
          localStorage.removeItem('tennis-auth-storage');
          window.location.reload();
          break;
        case 403:
          console.error('Доступ запрещён');
          break;
        case 404:
          console.error('Ресурс не найден');
          break;
        case 429:
          console.error('Слишком много запросов');
          break;
        case 500:
          console.error('Ошибка сервера');
          break;
        default:
          console.error('Ошибка:', data?.message || 'Неизвестная ошибка');
      }
    } else if (error.request) {
      console.error('Сервер не отвечает');
    } else {
      console.error('Ошибка запроса:', error.message);
    }
    
    return Promise.reject(error);
  }
);

// API методы для работы с пользователями
export const userApi = {
  // Получить профиль текущего пользователя
  getProfile: () => api.get('/users/me'),
  
  // Обновить профиль
  updateProfile: (data: { firstName?: string; lastName?: string; city?: string }) =>
    api.patch('/users/me', data),
  
  // Загрузить аватар
  uploadAvatar: (file: File) => {
    const formData = new FormData();
    formData.append('avatar', file);
    return api.post('/users/me/avatar', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
};

// API методы для работы с рейтингом
export const ratingApi = {
  // Получить рейтинг пользователя
  getUserRating: (userId: string) => api.get(`/rating/user/${userId}`),
  
  // Получить историю рейтинга
  getRatingHistory: (userId: string, period?: 'week' | 'month' | 'year') =>
    api.get(`/rating/user/${userId}/history`, { params: { period } }),
  
  // Получить таблицу лидеров
  getLeaderboard: (params?: { city?: string; limit?: number; offset?: number }) =>
    api.get('/rating/leaderboard', { params }),
};

// API методы для работы с играми
export const gamesApi = {
  // Получить список игр пользователя
  getUserGames: (userId: string, params?: { limit?: number; offset?: number }) =>
    api.get(`/games/user/${userId}`, { params }),
  
  // Создать заявку на игру
  createGameRequest: (data: {
    courtId?: string;
    date: string;
    time: string;
    duration: number;
    seekingLevel: [number, number];
    comment?: string;
  }) => api.post('/games/requests', data),
  
  // Получить активные заявки на игру
  getGameRequests: (params?: { city?: string; date?: string }) =>
    api.get('/games/requests', { params }),
  
  // Откликнуться на заявку
  respondToRequest: (requestId: string) =>
    api.post(`/games/requests/${requestId}/respond`),
  
  // Записать результат игры
  recordGameResult: (data: {
    opponentId: string;
    score: string;
    date: string;
  }) => api.post('/games/results', data),
};

// API методы для работы с кортами
export const courtsApi = {
  // Получить список кортов
  getCourts: (params?: { city?: string; free?: boolean; lat?: number; lng?: number }) =>
    api.get('/courts', { params }),
  
  // Получить информацию о корте
  getCourt: (courtId: string) => api.get(`/courts/${courtId}`),
};

// API методы для работы с турнирами
export const tournamentsApi = {
  // Получить список турниров
  getTournaments: (params?: { city?: string; status?: 'upcoming' | 'ongoing' | 'finished' }) =>
    api.get('/tournaments', { params }),
  
  // Получить информацию о турнире
  getTournament: (tournamentId: string) => api.get(`/tournaments/${tournamentId}`),
  
  // Зарегистрироваться на турнир
  registerForTournament: (tournamentId: string) =>
    api.post(`/tournaments/${tournamentId}/register`),
};

export default api;
