import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { api } from './api';

interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  photo_url?: string;
  is_premium?: boolean;
}

interface User {
  id: string;
  telegramId?: number;
  email?: string;
  firstName: string;
  lastName?: string;
  username?: string;
  photoUrl?: string;
  rating: number;
  city?: string;
  createdAt: string;
}

interface AuthState {
  // Состояние
  isAuthenticated: boolean;
  isLoading: boolean;
  user: User | null;
  token: string | null;
  
  // Действия
  setTelegramUser: (telegramUser: TelegramUser) => Promise<void>;
  loginWithEmail: (email: string, code: string) => Promise<void>;
  requestEmailCode: (email: string) => Promise<void>;
  logout: () => void;
  checkAuth: () => Promise<void>;
  updateUser: (data: Partial<User>) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      isAuthenticated: false,
      isLoading: false,
      user: null,
      token: null,

      // Авторизация через Telegram
      setTelegramUser: async (telegramUser: TelegramUser) => {
        set({ isLoading: true });
        
        try {
          // Получаем initData из Telegram WebApp
          const initData = window.Telegram?.WebApp?.initData || '';
          
          const response = await api.post('/auth/telegram', {
            initData,
            user: telegramUser,
          });

          const { user, token } = response.data;

          set({
            isAuthenticated: true,
            user,
            token,
            isLoading: false,
          });

          // Сохраняем токен для последующих запросов
          api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        } catch (error) {
          console.error('Ошибка авторизации через Telegram:', error);
          
          // В режиме разработки создаём тестового пользователя
          if (import.meta.env.DEV) {
            set({
              isAuthenticated: true,
              user: {
                id: 'dev-user',
                telegramId: telegramUser.id,
                firstName: telegramUser.first_name,
                lastName: telegramUser.last_name,
                username: telegramUser.username,
                photoUrl: telegramUser.photo_url,
                rating: 1548,
                city: 'Москва',
                createdAt: new Date().toISOString(),
              },
              token: 'dev-token',
              isLoading: false,
            });
          } else {
            set({ isLoading: false });
            throw error;
          }
        }
      },

      // Запрос кода на email
      requestEmailCode: async (email: string) => {
        set({ isLoading: true });
        
        try {
          await api.post('/auth/email/request-code', { email });
          set({ isLoading: false });
        } catch (error) {
          set({ isLoading: false });
          throw error;
        }
      },

      // Авторизация через Email
      loginWithEmail: async (email: string, code: string) => {
        set({ isLoading: true });
        
        try {
          const response = await api.post('/auth/email/verify', { email, code });
          const { user, token } = response.data;

          set({
            isAuthenticated: true,
            user,
            token,
            isLoading: false,
          });

          api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        } catch (error) {
          set({ isLoading: false });
          throw error;
        }
      },

      // Выход
      logout: () => {
        set({
          isAuthenticated: false,
          user: null,
          token: null,
        });
        
        delete api.defaults.headers.common['Authorization'];
        
        // Закрываем приложение в Telegram
        if (window.Telegram?.WebApp) {
          window.Telegram.WebApp.close();
        }
      },

      // Проверка авторизации при загрузке
      checkAuth: async () => {
        const { token } = get();
        
        if (!token) {
          set({ isAuthenticated: false });
          return;
        }

        set({ isLoading: true });
        api.defaults.headers.common['Authorization'] = `Bearer ${token}`;

        try {
          const response = await api.get('/auth/me');
          set({
            isAuthenticated: true,
            user: response.data,
            isLoading: false,
          });
        } catch (error) {
          // Токен невалидный, очищаем состояние
          set({
            isAuthenticated: false,
            user: null,
            token: null,
            isLoading: false,
          });
          delete api.defaults.headers.common['Authorization'];
        }
      },

      // Обновление данных пользователя
      updateUser: (data: Partial<User>) => {
        const { user } = get();
        if (user) {
          set({ user: { ...user, ...data } });
        }
      },
    }),
    {
      name: 'tennis-auth-storage',
      partialize: (state) => ({
        token: state.token,
        user: state.user,
      }),
    }
  )
);
