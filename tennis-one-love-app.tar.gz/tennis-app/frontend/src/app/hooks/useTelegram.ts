/**
 * Хук для работы с Telegram Web Apps API
 * Документация: https://core.telegram.org/bots/webapps
 */

import { useCallback, useEffect, useState } from 'react';

// Типы для Telegram Web App
interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  photo_url?: string;
  is_premium?: boolean;
}

interface ThemeParams {
  bg_color?: string;
  text_color?: string;
  hint_color?: string;
  link_color?: string;
  button_color?: string;
  button_text_color?: string;
  secondary_bg_color?: string;
}

interface WebAppInitData {
  query_id?: string;
  user?: TelegramUser;
  receiver?: TelegramUser;
  chat_instance?: string;
  chat_type?: string;
  start_param?: string;
  auth_date: number;
  hash: string;
}

interface HapticFeedback {
  impactOccurred: (style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft') => void;
  notificationOccurred: (type: 'error' | 'success' | 'warning') => void;
  selectionChanged: () => void;
}

interface MainButton {
  text: string;
  color: string;
  textColor: string;
  isVisible: boolean;
  isActive: boolean;
  isProgressVisible: boolean;
  setText: (text: string) => void;
  onClick: (callback: () => void) => void;
  offClick: (callback: () => void) => void;
  show: () => void;
  hide: () => void;
  enable: () => void;
  disable: () => void;
  showProgress: (leaveActive?: boolean) => void;
  hideProgress: () => void;
  setParams: (params: {
    text?: string;
    color?: string;
    text_color?: string;
    is_active?: boolean;
    is_visible?: boolean;
  }) => void;
}

interface BackButton {
  isVisible: boolean;
  onClick: (callback: () => void) => void;
  offClick: (callback: () => void) => void;
  show: () => void;
  hide: () => void;
}

interface TelegramWebApp {
  initData: string;
  initDataUnsafe: WebAppInitData;
  version: string;
  platform: string;
  colorScheme: 'light' | 'dark';
  themeParams: ThemeParams;
  isExpanded: boolean;
  viewportHeight: number;
  viewportStableHeight: number;
  headerColor: string;
  backgroundColor: string;
  isClosingConfirmationEnabled: boolean;
  HapticFeedback: HapticFeedback;
  MainButton: MainButton;
  BackButton: BackButton;
  
  ready: () => void;
  expand: () => void;
  close: () => void;
  sendData: (data: string) => void;
  openLink: (url: string, options?: { try_instant_view?: boolean }) => void;
  openTelegramLink: (url: string) => void;
  showPopup: (params: {
    title?: string;
    message: string;
    buttons?: Array<{
      id?: string;
      type?: 'default' | 'ok' | 'close' | 'cancel' | 'destructive';
      text?: string;
    }>;
  }, callback?: (buttonId: string) => void) => void;
  showAlert: (message: string, callback?: () => void) => void;
  showConfirm: (message: string, callback?: (confirmed: boolean) => void) => void;
  enableClosingConfirmation: () => void;
  disableClosingConfirmation: () => void;
  setHeaderColor: (color: string) => void;
  setBackgroundColor: (color: string) => void;
  onEvent: (eventType: string, callback: () => void) => void;
  offEvent: (eventType: string, callback: () => void) => void;
}

declare global {
  interface Window {
    Telegram?: {
      WebApp: TelegramWebApp;
    };
  }
}

export interface UseTelegramReturn {
  // Данные
  webApp: TelegramWebApp | null;
  user: TelegramUser | null;
  initData: string;
  initDataUnsafe: WebAppInitData | null;
  
  // Состояние
  isReady: boolean;
  isTelegram: boolean;
  colorScheme: 'light' | 'dark';
  themeParams: ThemeParams;
  viewportHeight: number;
  isExpanded: boolean;
  platform: string;
  
  // Методы
  ready: () => void;
  expand: () => void;
  close: () => void;
  
  // Haptic Feedback
  hapticImpact: (style?: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft') => void;
  hapticNotification: (type: 'error' | 'success' | 'warning') => void;
  hapticSelection: () => void;
  
  // Main Button
  showMainButton: (text: string, onClick: () => void) => void;
  hideMainButton: () => void;
  setMainButtonText: (text: string) => void;
  setMainButtonLoading: (loading: boolean) => void;
  
  // Back Button
  showBackButton: (onClick: () => void) => void;
  hideBackButton: () => void;
  
  // Dialogs
  showAlert: (message: string) => Promise<void>;
  showConfirm: (message: string) => Promise<boolean>;
  showPopup: (params: {
    title?: string;
    message: string;
    buttons?: Array<{
      id?: string;
      type?: 'default' | 'ok' | 'close' | 'cancel' | 'destructive';
      text?: string;
    }>;
  }) => Promise<string>;
  
  // Links
  openLink: (url: string) => void;
  openTelegramLink: (url: string) => void;
}

export function useTelegram(): UseTelegramReturn {
  const [webApp, setWebApp] = useState<TelegramWebApp | null>(null);
  const [isReady, setIsReady] = useState(false);

  // Инициализация при монтировании
  useEffect(() => {
    const tg = window.Telegram?.WebApp;
    
    if (tg) {
      setWebApp(tg);
      tg.ready();
      tg.expand();
      setIsReady(true);
      
      // Устанавливаем цвета в соответствии с темой
      if (tg.colorScheme === 'dark') {
        tg.setHeaderColor('#1a1a1a');
        tg.setBackgroundColor('#1a1a1a');
      } else {
        tg.setHeaderColor('#ffffff');
        tg.setBackgroundColor('#f5f5f5');
      }
    } else {
      // Для разработки вне Telegram
      console.warn('Telegram WebApp не доступен. Используется режим разработки.');
      setIsReady(true);
    }
  }, []);

  // Данные пользователя
  const user = webApp?.initDataUnsafe?.user || null;
  const initData = webApp?.initData || '';
  const initDataUnsafe = webApp?.initDataUnsafe || null;

  // Состояние
  const isTelegram = !!webApp;
  const colorScheme = webApp?.colorScheme || 'dark';
  const themeParams = webApp?.themeParams || {};
  const viewportHeight = webApp?.viewportHeight || window.innerHeight;
  const isExpanded = webApp?.isExpanded || false;
  const platform = webApp?.platform || 'unknown';

  // Базовые методы
  const ready = useCallback(() => {
    webApp?.ready();
  }, [webApp]);

  const expand = useCallback(() => {
    webApp?.expand();
  }, [webApp]);

  const close = useCallback(() => {
    webApp?.close();
  }, [webApp]);

  // Haptic Feedback
  const hapticImpact = useCallback((style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft' = 'medium') => {
    webApp?.HapticFeedback?.impactOccurred(style);
  }, [webApp]);

  const hapticNotification = useCallback((type: 'error' | 'success' | 'warning') => {
    webApp?.HapticFeedback?.notificationOccurred(type);
  }, [webApp]);

  const hapticSelection = useCallback(() => {
    webApp?.HapticFeedback?.selectionChanged();
  }, [webApp]);

  // Main Button
  const mainButtonCallback = useCallback({ current: () => {} }, []);

  const showMainButton = useCallback((text: string, onClick: () => void) => {
    if (webApp?.MainButton) {
      webApp.MainButton.offClick(mainButtonCallback.current);
      mainButtonCallback.current = onClick;
      webApp.MainButton.setText(text);
      webApp.MainButton.onClick(onClick);
      webApp.MainButton.show();
    }
  }, [webApp, mainButtonCallback]);

  const hideMainButton = useCallback(() => {
    if (webApp?.MainButton) {
      webApp.MainButton.offClick(mainButtonCallback.current);
      webApp.MainButton.hide();
    }
  }, [webApp, mainButtonCallback]);

  const setMainButtonText = useCallback((text: string) => {
    webApp?.MainButton?.setText(text);
  }, [webApp]);

  const setMainButtonLoading = useCallback((loading: boolean) => {
    if (loading) {
      webApp?.MainButton?.showProgress();
    } else {
      webApp?.MainButton?.hideProgress();
    }
  }, [webApp]);

  // Back Button
  const backButtonCallback = useCallback({ current: () => {} }, []);

  const showBackButton = useCallback((onClick: () => void) => {
    if (webApp?.BackButton) {
      webApp.BackButton.offClick(backButtonCallback.current);
      backButtonCallback.current = onClick;
      webApp.BackButton.onClick(onClick);
      webApp.BackButton.show();
    }
  }, [webApp, backButtonCallback]);

  const hideBackButton = useCallback(() => {
    if (webApp?.BackButton) {
      webApp.BackButton.offClick(backButtonCallback.current);
      webApp.BackButton.hide();
    }
  }, [webApp, backButtonCallback]);

  // Dialogs
  const showAlert = useCallback((message: string): Promise<void> => {
    return new Promise((resolve) => {
      if (webApp) {
        webApp.showAlert(message, resolve);
      } else {
        alert(message);
        resolve();
      }
    });
  }, [webApp]);

  const showConfirm = useCallback((message: string): Promise<boolean> => {
    return new Promise((resolve) => {
      if (webApp) {
        webApp.showConfirm(message, resolve);
      } else {
        resolve(confirm(message));
      }
    });
  }, [webApp]);

  const showPopup = useCallback((params: {
    title?: string;
    message: string;
    buttons?: Array<{
      id?: string;
      type?: 'default' | 'ok' | 'close' | 'cancel' | 'destructive';
      text?: string;
    }>;
  }): Promise<string> => {
    return new Promise((resolve) => {
      if (webApp) {
        webApp.showPopup(params, resolve);
      } else {
        alert(params.message);
        resolve('ok');
      }
    });
  }, [webApp]);

  // Links
  const openLink = useCallback((url: string) => {
    if (webApp) {
      webApp.openLink(url);
    } else {
      window.open(url, '_blank');
    }
  }, [webApp]);

  const openTelegramLink = useCallback((url: string) => {
    if (webApp) {
      webApp.openTelegramLink(url);
    } else {
      window.open(url, '_blank');
    }
  }, [webApp]);

  return {
    // Данные
    webApp,
    user,
    initData,
    initDataUnsafe,
    
    // Состояние
    isReady,
    isTelegram,
    colorScheme,
    themeParams,
    viewportHeight,
    isExpanded,
    platform,
    
    // Методы
    ready,
    expand,
    close,
    
    // Haptic Feedback
    hapticImpact,
    hapticNotification,
    hapticSelection,
    
    // Main Button
    showMainButton,
    hideMainButton,
    setMainButtonText,
    setMainButtonLoading,
    
    // Back Button
    showBackButton,
    hideBackButton,
    
    // Dialogs
    showAlert,
    showConfirm,
    showPopup,
    
    // Links
    openLink,
    openTelegramLink,
  };
}

export default useTelegram;
