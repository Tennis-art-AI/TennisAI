import { LineChart, Line, ResponsiveContainer, XAxis, YAxis } from 'recharts';
import { useState } from 'react';
import { Plus, Settings, X, Check, AlertCircle } from 'lucide-react';

const ratingData = [
  { month: 'Янв', rating: 1420 },
  { month: 'Фев', rating: 1450 },
  { month: 'Мар', rating: 1480 },
  { month: 'Апр', rating: 1465 },
  { month: 'Май', rating: 1510 },
  { month: 'Июн', rating: 1548 },
];

const lastGames = [
  { 
    player1: 'Иван Петров', 
    player2: 'Алекс Морган', 
    score: '6:2, 6:3', 
    date: '18 янв, 2026', 
    time: '14:30',
    result: 'win'
  },
  { 
    player1: 'Иван Петров', 
    player2: 'Джордан Ли', 
    score: '7:5, 3:6, 6:4', 
    date: '15 янв, 2026', 
    time: '10:00',
    result: 'win'
  },
  { 
    player1: 'Иван Петров', 
    player2: 'Сэм Тейлор', 
    score: '6:4, 6:2', 
    date: '12 янв, 2026', 
    time: '16:45',
    result: 'loss'
  },
];

const stats = {
  won: 30,
  lost: 7,
  total: 37,
  winPercentage: 81,
};

export function ProfilePage() {
  return (
    <div className="flex-1 flex items-center justify-center pb-20">
      <div className="text-center space-y-4 px-6">
        <div className="text-6xl">🏆</div>
        <h2 className="text-2xl font-bold text-white">Турниры</h2>
        <p className="text-gray-400">Раздел находится в разработке</p>
      </div>
    </div>
  );
}

export function RatingPage() {
  const [activeFilter, setActiveFilter] = useState<'last5' | 'last10' | 'all'>('last5');
  const [showAllPlayers, setShowAllPlayers] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Данные для разных фильтров
  const ratingDataLast5 = [
    { month: 'Фев', rating: 1450 },
    { month: 'Мар', rating: 1480 },
    { month: 'Апр', rating: 1465 },
    { month: 'Май', rating: 1510 },
    { month: 'Июн', rating: 1548 },
  ];
  
  const ratingDataLast10 = [
    { month: 'Янв', rating: 1420 },
    { month: 'Фев', rating: 1450 },
    { month: 'Мар', rating: 1480 },
    { month: 'Апр', rating: 1465 },
    { month: 'Май', rating: 1510 },
    { month: 'Июн', rating: 1548 },
  ];
  
  const ratingDataAll = ratingDataLast10;
  
  const getCurrentData = () => {
    switch (activeFilter) {
      case 'last5':
        return ratingDataLast5;
      case 'last10':
        return ratingDataLast10;
      case 'all':
        return ratingDataAll;
      default:
        return ratingDataLast10;
    }
  };
  
  const singlesStats = {
    total: 25,
    won: 20,
    lost: 5,
    winPercentage: 80,
  };
  
  const doublesStats = {
    total: 12,
    won: 10,
    lost: 2,
    winPercentage: 83,
  };

  // Список всех игроков
  const allPlayers = [
    { id: 1, name: 'Иван Петров', city: 'Нью-Йорк, США', rating: 1548 },
    { id: 2, name: 'Алекс Морган', city: 'Лос-Анджелес, США', rating: 1532 },
    { id: 3, name: 'Джордан Ли', city: 'Чикаго, США', rating: 1518 },
    { id: 4, name: 'Сэм Тейлор', city: 'Майами, США', rating: 1505 },
    { id: 5, name: 'Мария Гарсия', city: 'Бостон, США', rating: 1490 },
    { id: 6, name: 'Дэвид Смит', city: 'Сиэтл, США', rating: 1475 },
    { id: 7, name: 'Анна Джонсон', city: 'Денвер, США', rating: 1460 },
    { id: 8, name: 'Карлос Родригес', city: 'Хьюстон, США', rating: 1445 },
    { id: 9, name: 'Эмили Браун', city: 'Феникс, США', rating: 1430 },
    { id: 10, name: 'Майкл Уилсон', city: 'Атланта, США', rating: 1415 },
    { id: 11, name: 'София Мартинес', city: 'Сан-Диего, США', rating: 1400 },
    { id: 12, name: 'Джеймс Андерсон', city: 'Даллас, США', rating: 1385 },
    { id: 13, name: 'Оливия Томас', city: 'Остин, США', rating: 1370 },
    { id: 14, name: 'Уильям Джексон', city: 'Портленд, США', rating: 1355 },
    { id: 15, name: 'Эмма Уайт', city: 'Лас-Вегас, США', rating: 1340 },
  ];

  const filteredPlayers = allPlayers.filter(player =>
    player.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (showAllPlayers) {
    return (
      <div className="flex-1 overflow-hidden pb-20 flex flex-col">
        {/* Header with search */}
        <div className="px-4 py-3 space-y-3 flex-shrink-0">
          <h2 className="text-white text-lg font-medium">Рейтинг игроков</h2>
          
          {/* Search Input */}
          <div className="relative">
            <input
              type="text"
              placeholder="Найти игрока"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#2a2a2a] text-white rounded-lg px-4 py-2.5 text-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-lime-500"
            />
          </div>
        </div>

        {/* Players List - прокручиваемый */}
        <div className="flex-1 overflow-y-auto px-4 pb-4">
          <div className="space-y-2">
            {filteredPlayers.map((player, index) => (
              <div
                key={player.id}
                className="bg-[#2a2a2a] rounded-lg p-3 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-lime-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                    {index + 1}
                  </div>
                  <div>
                    <div className="text-white text-sm font-medium">{player.name}</div>
                    <div className="text-gray-400 text-xs">{player.city}</div>
                  </div>
                </div>
                <div className="text-white font-bold text-base">{player.rating}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Back Button */}
        <div className="px-4 pb-3 flex-shrink-0">
          <button
            onClick={() => {
              setShowAllPlayers(false);
              setSearchQuery('');
            }}
            className="w-full bg-lime-500 hover:bg-lime-600 text-white py-3 rounded-lg font-medium transition-colors"
          >
            Назад
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto overflow-x-hidden pb-20 flex flex-col">
      {/* Top spacing - 10% экрана (85px) */}
      <div className="h-[85px] flex-shrink-0"></div>
      
      <div className="px-4 py-3 space-y-3">
        {/* Rating Section */}
        <div className="space-y-1">
          <div className="flex items-baseline gap-2">
            <span className="text-sm text-gray-400">Рейтинг</span>
            <span className="text-sm font-bold text-white">1548</span>
          </div>
        </div>

        {/* Statistics Filter Buttons - над графиком */}
        <div className="space-y-2">
          <div className="flex gap-3">
            <button
              onClick={() => setActiveFilter('last5')}
              className={`text-xs font-medium transition-colors ${
                activeFilter === 'last5'
                  ? 'text-lime-400 underline'
                  : 'text-gray-400 hover:text-gray-300'
              }`}
            >
              Последние 5 игр
            </button>
            <button
              onClick={() => setActiveFilter('last10')}
              className={`text-xs font-medium transition-colors ${
                activeFilter === 'last10'
                  ? 'text-lime-400 underline'
                  : 'text-gray-400 hover:text-gray-300'
              }`}
            >
              Последние 10 игр
            </button>
            <button
              onClick={() => setActiveFilter('all')}
              className={`text-xs font-medium transition-colors ${
                activeFilter === 'all'
                  ? 'text-lime-400 underline'
                  : 'text-gray-400 hover:text-gray-300'
              }`}
            >
              Все игры
            </button>
          </div>
        </div>

        {/* Rating History Chart */}
        <div className="space-y-2">
          <h3 className="text-white text-xs font-medium">История рейтинга</h3>
          <div className="bg-[#2a2a2a] rounded-lg p-3">
            <div className="h-20">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={getCurrentData()}>
                  <XAxis
                    dataKey="month"
                    stroke="#6b7280"
                    style={{ fontSize: '9px' }}
                  />
                  <YAxis
                    stroke="#6b7280"
                    style={{ fontSize: '9px' }}
                    domain={[1400, 1600]}
                  />
                  <Line
                    type="monotone"
                    dataKey="rating"
                    stroke="#10b981"
                    strokeWidth={2}
                    dot={{ fill: '#10b981', r: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Combined Stats - 4 колонки */}
        <div className="space-y-2">
          <h3 className="text-white text-xs font-medium">Статистика</h3>
          <div className="bg-[#2a2a2a] rounded-lg p-3">
            {/* Singles Stats */}
            <div className="mb-3">
              <h4 className="text-white text-xs font-medium mb-2">Статистика одиночных матчей</h4>
              <div className="grid grid-cols-4 gap-2 text-center">
                <div>
                  <div className="text-white font-semibold text-sm">{singlesStats.total}</div>
                  <div className="text-gray-400 text-[9px]">Всего игр</div>
                </div>
                <div>
                  <div className="text-emerald-400 font-semibold text-sm">{singlesStats.won}</div>
                  <div className="text-gray-400 text-[9px]">Побед</div>
                </div>
                <div>
                  <div className="text-red-400 font-semibold text-sm">{singlesStats.lost}</div>
                  <div className="text-gray-400 text-[9px]">Поражений</div>
                </div>
                <div>
                  <div className="text-emerald-400 font-bold text-sm">{singlesStats.winPercentage}%</div>
                  <div className="text-gray-400 text-[9px]">Побед</div>
                </div>
              </div>
            </div>

            {/* Doubles Stats */}
            <div className="pt-3 border-t border-gray-700">
              <h4 className="text-white text-xs font-medium mb-2">Статистика парных матчей</h4>
              <div className="grid grid-cols-4 gap-2 text-center">
                <div>
                  <div className="text-white font-semibold text-sm">{doublesStats.total}</div>
                  <div className="text-gray-400 text-[9px]">Всего игр</div>
                </div>
                <div>
                  <div className="text-emerald-400 font-semibold text-sm">{doublesStats.won}</div>
                  <div className="text-gray-400 text-[9px]">Побед</div>
                </div>
                <div>
                  <div className="text-red-400 font-semibold text-sm">{doublesStats.lost}</div>
                  <div className="text-gray-400 text-[9px]">Поражений</div>
                </div>
                <div>
                  <div className="text-emerald-400 font-bold text-sm">{doublesStats.winPercentage}%</div>
                  <div className="text-gray-400 text-[9px]">Побед</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* View All Players Button - поднят выше */}
        <div className="pt-2">
          <button
            onClick={() => setShowAllPlayers(true)}
            className="w-full bg-lime-500 hover:bg-lime-600 text-white py-3 rounded-lg font-medium transition-colors"
          >
            Посмотреть рейтинг всех игроков
          </button>
        </div>
      </div>
    </div>
  );
}

export function PlayPage() {
  const [gameType, setGameType] = useState<'singles' | 'doubles' | 'training' | 'tournament' | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [showCreateRequest, setShowCreateRequest] = useState(false);
  const [selectedCity, setSelectedCity] = useState('Нью-Йорк, США');
  const [selectedCourts, setSelectedCourts] = useState<string[]>([]);
  const [levelRange, setLevelRange] = useState<[number, number]>([2, 4]);
  const [dateRange, setDateRange] = useState<string>('');
  const [showCitySelect, setShowCitySelect] = useState(false);
  const [showCourtSelect, setShowCourtSelect] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [comment, setComment] = useState('');
  const [playerInvite, setPlayerInvite] = useState('');
  const [showPlayerSuggestions, setShowPlayerSuggestions] = useState(false);
  const [startTime, setStartTime] = useState('12:00');
  const [endTime, setEndTime] = useState('13:00');
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [showEndTimePicker, setShowEndTimePicker] = useState(false);

  const courts = ['Tennis lawn', 'Будь здоров', 'Олимпиец-3', 'ITC WebGym Царицыно', 'Лужники'];
  const cities = ['Нью-Йорк, США', 'Лос-Анджелес, США', 'Чикаго, США', 'Майами, США', 'Бостон, США'];

  interface Participant {
    name: string;
    photo?: string;
  }

  interface GameRequest {
    id: number;
    player: string;
    level: number;
    court: string;
    date: string;
    time: string;
    type: 'singles' | 'doubles' | 'training' | 'tournament';
    participants: Participant[];
    maxParticipants: number;
    duration: number; // в часах
    seekingLevelRange: [number, number]; // диапазон искомых уровней
    comment?: string; // комментарий до 30 символов
  }

  const gameRequests: GameRequest[] = [
    { 
      id: 1, 
      player: 'Алекс Морган', 
      level: 3.8, 
      court: 'Tennis lawn', 
      date: '24 янв', 
      time: '14:00', 
      type: 'singles',
      participants: [{ name: 'Алекс Морган', photo: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100' }],
      maxParticipants: 2,
      duration: 2,
      seekingLevelRange: [3.5, 4.2],
      comment: 'Сыграем на результат'
    },
    { 
      id: 2, 
      player: 'Джордан Ли', 
      level: 2.6, 
      court: 'Будь здоров', 
      date: '24 янв', 
      time: '16:30', 
      type: 'singles',
      participants: [
        { name: 'Джордан Ли' },
        { name: 'Мария Гарсия', photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100' }
      ],
      maxParticipants: 2,
      duration: 1.5,
      seekingLevelRange: [2.4, 3.0]
    },
    { 
      id: 3, 
      player: 'Сэм Тейлор', 
      level: 4.2, 
      court: 'Олимпиец-3', 
      date: '25 янв', 
      time: '10:00', 
      type: 'doubles',
      participants: [
        { name: 'Сэм Тейлор', photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100' },
        { name: 'Анна Джонсон' }
      ],
      maxParticipants: 4,
      duration: 3,
      seekingLevelRange: [3.8, 4.5],
      comment: 'Ищем сильных игроков'
    },
    { 
      id: 4, 
      player: 'Мария Гарсия', 
      level: 3.4, 
      court: 'ITC WebGym Царицыно', 
      date: '25 янв', 
      time: '18:00', 
      type: 'singles',
      participants: [{ name: 'Мария Гарсия', photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100' }],
      maxParticipants: 2,
      duration: 2,
      seekingLevelRange: [3.0, 3.8],
      comment: 'Дружеская игра'
    },
    { 
      id: 5, 
      player: 'Дэвид Смит', 
      level: 2.8, 
      court: 'Лужники', 
      date: '26 янв', 
      time: '12:00', 
      type: 'training',
      participants: [
        { name: 'Дэвид Смит' },
        { name: 'Карлос Родригес', photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100' },
        { name: 'Эмили Браун' }
      ],
      maxParticipants: 6,
      duration: 4,
      seekingLevelRange: [2.0, 3.5]
    },
    { 
      id: 6, 
      player: 'Анна Джонсон', 
      level: 3.6, 
      court: 'Tennis lawn', 
      date: '26 янв', 
      time: '15:30', 
      type: 'singles',
      participants: [{ name: 'Анна Джонсон' }],
      maxParticipants: 2,
      duration: 1,
      seekingLevelRange: [3.2, 4.0]
    },
    { 
      id: 7, 
      player: 'Карлос Родригес', 
      level: 4.0, 
      court: 'Будь здоров', 
      date: '27 янв', 
      time: '11:00', 
      type: 'doubles',
      participants: [
        { name: 'Карлос Родригес', photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100' },
        { name: 'Эмили Браун' },
        { name: 'Джон Доу', photo: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100' },
        { name: 'Джейн Смит' }
      ],
      maxParticipants: 4,
      duration: 2.5,
      seekingLevelRange: [3.5, 4.5],
      comment: 'Нужны опытные партнеры'
    },
    { 
      id: 8, 
      player: 'Эмили Браун', 
      level: 2.4, 
      court: 'Олимпиец-3', 
      date: '27 янв', 
      time: '17:00', 
      type: 'singles',
      participants: [{ name: 'Эмили Браун' }],
      maxParticipants: 2,
      duration: 1.5,
      seekingLevelRange: [2.0, 2.8],
      comment: 'Играю для удовольствия'
    },
    {
      id: 9,
      player: 'Иван Петров',
      level: 3.9,
      court: 'Tennis lawn',
      date: '28 янв',
      time: '09:00',
      type: 'tournament',
      participants: [
        { name: 'Иван Петров', photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100' },
        { name: 'Алекс Морган', photo: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100' },
        { name: 'Джордан Ли' },
        { name: 'Сэм Тейлор', photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100' },
        { name: 'Мария Гарсия', photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100' },
        { name: 'Дэвд Смит' },
        { name: 'Анна Джонсон' },
        { name: 'Карлос Родригес', photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100' }
      ],
      maxParticipants: 16,
      duration: 6,
      seekingLevelRange: [3.0, 5.0],
      comment: 'Большой турнир выходного дня'
    }
  ];

  // Helper function to calculate end time
  const calculateEndTime = (startTime: string, durationHours: number): string => {
    const [hours, minutes] = startTime.split(':').map(Number);
    const totalMinutes = hours * 60 + minutes + durationHours * 60;
    const endHours = Math.floor(totalMinutes / 60) % 24;
    const endMinutes = totalMinutes % 60;
    return `${String(endHours).padStart(2, '0')}:${String(endMinutes).padStart(2, '0')}`;
  };

  const toggleCourt = (court: string) => {
    if (selectedCourts.includes(court)) {
      setSelectedCourts(selectedCourts.filter(c => c !== court));
    } else {
      setSelectedCourts([...selectedCourts, court]);
    }
  };

  // Component for participant circles
  const ParticipantCircles = ({ participants, maxParticipants }: { participants: Participant[], maxParticipants: number }) => {
    const circles = [];
    
    for (let i = 0; i < maxParticipants; i++) {
      const participant = participants[i];
      circles.push(
        <div key={i} className="flex flex-col items-center gap-1">
          <div className="w-10 h-10 rounded-full bg-[#1a1a1a] border-2 border-lime-500/30 flex items-center justify-center overflow-hidden">
            {participant?.photo ? (
              <img src={participant.photo} alt={participant.name} className="w-full h-full object-cover" />
            ) : participant ? (
              <div className="text-lime-500 text-lg">🎾</div>
            ) : (
              <div className="text-gray-600 text-lg">🎾</div>
            )}
          </div>
          {participant && (
            <div className="text-[8px] text-gray-400 text-center max-w-[50px] truncate">
              {participant.name}
            </div>
          )}
        </div>
      );
    }
    
    return (
      <div className="flex gap-2 flex-wrap">
        {circles}
      </div>
    );
  };

  // Filters Modal
  if (showFilters) {
    return (
      <div className="flex-1 overflow-y-auto pb-20">
        <div className="px-4 py-3 space-y-4">
          {/* Header */}
          <div className="flex items-center justify-between">
            <h2 className="text-white text-lg font-medium">Фильтры</h2>
            <button onClick={() => setShowFilters(false)} className="text-gray-400 hover:text-white">
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* City Filter */}
          <div className="space-y-2">
            <h3 className="text-white text-sm font-medium">Город</h3>
            <button
              onClick={() => setShowCitySelect(!showCitySelect)}
              className="w-full bg-[#2a2a2a] text-white rounded-lg px-4 py-3 text-sm text-left hover:bg-[#333333] transition-colors"
            >
              {selectedCity}
            </button>
            {showCitySelect && (
              <div className="bg-[#2a2a2a] rounded-lg overflow-hidden">
                {cities.map((city) => (
                  <button
                    key={city}
                    onClick={() => {
                      setSelectedCity(city);
                      setShowCitySelect(false);
                    }}
                    className="w-full px-4 py-2.5 text-sm text-left hover:bg-[#333333] transition-colors text-white"
                  >
                    {city}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Courts Filter */}
          <div className="space-y-2">
            <h3 className="text-white text-sm font-medium">Корты</h3>
            <button
              onClick={() => setShowCourtSelect(!showCourtSelect)}
              className="w-full bg-[#2a2a2a] text-white rounded-lg px-4 py-3 text-sm text-left hover:bg-[#333333] transition-colors"
            >
              {selectedCourts.length > 0 ? `Выбрано: ${selectedCourts.length}` : 'Выберите корты'}
            </button>
            {showCourtSelect && (
              <div className="bg-[#2a2a2a] rounded-lg p-3 space-y-2">
                {courts.map((court) => (
                  <button
                    key={court}
                    onClick={() => toggleCourt(court)}
                    className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-[#333333] transition-colors"
                  >
                    <span className="text-white text-sm">{court}</span>
                    {selectedCourts.includes(court) && (
                      <Check className="w-5 h-5 text-lime-500" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Level Filter */}
          <div className="space-y-1">
            <h3 className="text-white text-xs font-medium">Уровень игры</h3>
            <div className="bg-[#2a2a2a] rounded-lg p-2">
              <div className="flex justify-between mb-1">
                <span className="text-white text-xs font-medium">{levelRange[0].toFixed(1)}</span>
                <span className="text-white text-xs font-medium">{levelRange[1].toFixed(1)}</span>
              </div>
              <div className="relative h-6">
                <div className="absolute top-1/2 -translate-y-1/2 w-full h-1 bg-gray-600 rounded-full" />
                <div
                  className="absolute top-1/2 -translate-y-1/2 h-1 bg-lime-500 rounded-full"
                  style={{
                    left: `${((levelRange[0] - 1) / 4) * 100}%`,
                    right: `${100 - ((levelRange[1] - 1) / 4) * 100}%`,
                  }}
                />
                <input
                  type="range"
                  min="1"
                  max="5"
                  step="0.1"
                  value={levelRange[0]}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    if (val < levelRange[1]) setLevelRange([val, levelRange[1]]);
                  }}
                  className="absolute w-full appearance-none bg-transparent pointer-events-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-lime-400 [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:shadow-lg"
                />
                <input
                  type="range"
                  min="1"
                  max="5"
                  step="0.1"
                  value={levelRange[1]}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    if (val > levelRange[0]) setLevelRange([levelRange[0], val]);
                  }}
                  className="absolute w-full appearance-none bg-transparent pointer-events-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-lime-400 [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:shadow-lg"
                />
              </div>
              <div className="flex justify-between mt-1">
                <span className="text-gray-400 text-[10px]">1.0</span>
                <span className="text-gray-400 text-[10px]">5.0</span>
              </div>
            </div>
          </div>

          {/* Date Filter */}
          <div className="space-y-2">
            <h3 className="text-white text-sm font-medium">Дата</h3>
            <input
              type="date"
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="w-full bg-[#2a2a2a] text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-lime-500"
            />
          </div>

          {/* Apply Button */}
          <button
            onClick={() => setShowFilters(false)}
            className="w-full bg-lime-500 hover:bg-lime-600 text-white py-3 rounded-lg font-medium transition-colors mt-6"
          >
            Применить фильтры
          </button>
        </div>
      </div>
    );
  }

  // Create Request Modal
  if (showCreateRequest) {
    // Список игроков для поиска
    const allPlayers = [
      { id: 1, name: 'Алекс Морган', nickname: '@alexmorgan', level: 3.8 },
      { id: 2, name: 'Джордан Ли', nickname: '@jordanlee', level: 2.6 },
      { id: 3, name: 'Сэм Тейлор', nickname: '@samtaylor', level: 4.2 },
      { id: 4, name: 'Мария Гарсия', nickname: '@mariagarcia', level: 3.4 },
      { id: 5, name: 'Дэвид Смит', nickname: '@davidsmith', level: 2.8 },
    ];

    const filteredPlayers = playerInvite
      ? allPlayers.filter(
          (p) =>
            p.name.toLowerCase().includes(playerInvite.toLowerCase()) ||
            p.nickname.toLowerCase().includes(playerInvite.toLowerCase())
        )
      : [];

    // Генерация временных интервалов
    const generateTimeOptions = () => {
      const times = [];
      for (let h = 0; h < 24; h++) {
        for (let m = 0; m < 60; m += 30) {
          times.push(`${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`);
        }
      }
      return times;
    };

    const timeOptions = generateTimeOptions();

    // Генерация длительности от 1 часа до 8 часов с шагом 30 минут
    const generateDurationOptions = () => {
      const durations = [];
      for (let h = 1; h <= 8; h++) {
        durations.push({ value: h, label: `${h} ч` });
        if (h < 8) {
          durations.push({ value: h + 0.5, label: `${h} ч 30 мин` });
        }
      }
      return durations;
    };

    const durationOptions = generateDurationOptions();

    return (
      <div className="flex-1 overflow-y-auto pb-20 flex flex-col">
        <div className="flex-1 overflow-y-auto px-4 py-2">
          <div className="space-y-2">

          {/* Close Button - только крестик в правом верхнем углу */}
          <div className="flex justify-end mb-1">
            <button onClick={() => setShowCreateRequest(false)} className="text-gray-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* City */}
          <div className="space-y-1">
            <h3 className="text-white text-xs font-medium">Город</h3>
            <button
              onClick={() => setShowCitySelect(!showCitySelect)}
              className="w-full bg-[#2a2a2a] text-white rounded-lg px-3 py-2 text-sm text-left hover:bg-[#333333] transition-colors"
            >
              {selectedCity}
            </button>
            {showCitySelect && (
              <div className="bg-[#2a2a2a] rounded-lg overflow-hidden">
                {cities.map((city) => (
                  <button
                    key={city}
                    onClick={() => {
                      setSelectedCity(city);
                      setShowCitySelect(false);
                    }}
                    className="w-full px-4 py-2.5 text-sm text-left hover:bg-[#333333] transition-colors text-white"
                  >
                    {city}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Courts */}
          <div className="space-y-1">
            <h3 className="text-white text-xs font-medium">Корты</h3>
            <button
              onClick={() => setShowCourtSelect(!showCourtSelect)}
              className="w-full bg-[#2a2a2a] text-white rounded-lg px-3 py-2 text-sm text-left hover:bg-[#333333] transition-colors"
            >
              {selectedCourts.length > 0 ? selectedCourts[0] : 'Выберите корт'}
            </button>
            {showCourtSelect && (
              <div className="bg-[#2a2a2a] rounded-lg overflow-hidden">
                {courts.map((court) => (
                  <button
                    key={court}
                    onClick={() => {
                      setSelectedCourts([court]);
                      setShowCourtSelect(false);
                    }}
                    className="w-full px-4 py-2.5 text-sm text-left hover:bg-[#333333] transition-colors text-white"
                  >
                    {court}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Level */}
          <div className="space-y-1">
            <h3 className="text-white text-xs font-medium">Уровень игры</h3>
            <div className="bg-[#2a2a2a] rounded-lg p-2">
              <div className="flex justify-between mb-1">
                <span className="text-white text-xs font-medium">{levelRange[0].toFixed(1)}</span>
                <span className="text-white text-xs font-medium">{levelRange[1].toFixed(1)}</span>
              </div>
              <div className="relative h-6">
                <div className="absolute top-1/2 -translate-y-1/2 w-full h-1 bg-gray-600 rounded-full" />
                <div
                  className="absolute top-1/2 -translate-y-1/2 h-1 bg-lime-500 rounded-full"
                  style={{
                    left: `${((levelRange[0] - 1) / 4) * 100}%`,
                    right: `${100 - ((levelRange[1] - 1) / 4) * 100}%`,
                  }}
                />
                <input
                  type="range"
                  min="1"
                  max="5"
                  step="0.1"
                  value={levelRange[0]}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    if (val < levelRange[1]) setLevelRange([val, levelRange[1]]);
                  }}
                  className="absolute w-full appearance-none bg-transparent pointer-events-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-lime-400 [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:shadow-lg"
                />
                <input
                  type="range"
                  min="1"
                  max="5"
                  step="0.1"
                  value={levelRange[1]}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    if (val > levelRange[0]) setLevelRange([levelRange[0], val]);
                  }}
                  className="absolute w-full appearance-none bg-transparent pointer-events-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-lime-400 [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:shadow-lg"
                />
              </div>
              <div className="flex justify-between mt-1">
                <span className="text-gray-400 text-[10px]">1.0</span>
                <span className="text-gray-400 text-[10px]">5.0</span>
              </div>
            </div>
          </div>

          {/* Date */}
          <div className="space-y-1">
            <h3 className="text-white text-xs font-medium">Дата</h3>
            <input
              type="date"
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="w-full bg-[#2a2a2a] text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-lime-500"
            />
          </div>

          {/* Time and Duration - Combined */}
          <div className="space-y-1">
            <h3 className="text-white text-xs font-medium">Время и длительность</h3>
            <button
              onClick={() => setShowTimePicker(!showTimePicker)}
              className="w-full bg-[#2a2a2a] text-white rounded-lg px-3 py-2 text-sm text-left hover:bg-[#333333] transition-colors"
            >
              {startTime} - {endTime}
            </button>
            {showTimePicker && (
              <div className="bg-[#2a2a2a] rounded-lg p-3 space-y-3">
                {/* Start Time Selector */}
                <div className="space-y-1">
                  <h4 className="text-white text-xs">Время начала</h4>
                  <div className="bg-[#1a1a1a] rounded-lg max-h-32 overflow-y-auto">
                    {timeOptions.map((time) => (
                      <button
                        key={time}
                        onClick={() => setStartTime(time)}
                        className={`w-full px-3 py-2 text-sm text-left transition-colors ${
                          startTime === time
                            ? 'bg-lime-500 text-white'
                            : 'text-white hover:bg-[#333333]'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* End Time Selector */}
                <div className="space-y-1">
                  <h4 className="text-white text-xs">Время окончания</h4>
                  <div className="bg-[#1a1a1a] rounded-lg max-h-32 overflow-y-auto">
                    {timeOptions.map((time) => (
                      <button
                        key={time}
                        onClick={() => setEndTime(time)}
                        className={`w-full px-3 py-2 text-sm text-left transition-colors ${
                          endTime === time
                            ? 'bg-lime-500 text-white'
                            : 'text-white hover:bg-[#333333]'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Confirm Button */}
                <button
                  onClick={() => setShowTimePicker(false)}
                  className="w-full bg-lime-500 hover:bg-lime-600 text-white py-2 rounded-lg text-xs font-medium transition-colors"
                >
                  Подтвердить
                </button>
              </div>
            )}
          </div>

          {/* Comment */}
          <div className="space-y-1">
            <h3 className="text-white text-xs font-medium">Комментарий</h3>
            <input
              type="text"
              maxLength={30}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Добавьте комментарий (макс. 30 символов)"
              className="w-full bg-[#2a2a2a] text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-lime-500 placeholder-gray-500"
            />
            <div className="text-gray-400 text-xs text-right">{comment.length}/30</div>
          </div>

          {/* Invite Players */}
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <h3 className="text-white text-xs font-medium">Пригласить игроков</h3>
              <div className="relative group">
                <div className="w-4 h-4 rounded-full bg-gray-600 flex items-center justify-center cursor-help">
                  <AlertCircle className="w-3 h-3 text-gray-300" />
                </div>
                <div className="absolute left-0 top-6 hidden group-hover:block bg-[#1a1a1a] text-white text-xs rounded-lg px-3 py-2 w-48 z-10 shadow-lg">
                  Введи имя и фамилию или ник игрока в telegram
                </div>
              </div>
            </div>
            <div className="relative">
              <input
                type="text"
                value={playerInvite}
                onChange={(e) => {
                  setPlayerInvite(e.target.value);
                  setShowPlayerSuggestions(e.target.value.length > 0);
                }}
                placeholder="Введите имя или @nickname"
                className="w-full bg-[#2a2a2a] text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-lime-500 placeholder-gray-500"
              />
              {showPlayerSuggestions && filteredPlayers.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-[#2a2a2a] rounded-lg overflow-hidden shadow-lg z-10 max-h-48 overflow-y-auto">
                  {filteredPlayers.map((player) => (
                    <button
                      key={player.id}
                      onClick={() => {
                        setPlayerInvite('');
                        setShowPlayerSuggestions(false);
                      }}
                      className="w-full px-4 py-2.5 text-left hover:bg-[#333333] transition-colors"
                    >
                      <div className="text-white text-sm">{player.name}</div>
                      <div className="text-gray-400 text-xs">
                        {player.nickname} • Уровень {player.level}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Create Game Button */}
          <button
            onClick={() => {
              setShowCreateRequest(false);
              // Здесь будет логика создания игры
            }}
            className="w-full bg-lime-500 hover:bg-lime-600 text-white py-3 rounded-lg font-medium transition-colors mt-6"
          >
            Создать игру
          </button>
        </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-hidden pb-20 flex flex-col">
      {/* Top spacing - уменьшен с 85px до 25px (поднято на 3 строки) */}
      <div className="h-[25px] flex-shrink-0"></div>
      
      {/* Title - поднят выше на 3 строки */}
      <div className="px-4 pb-1 flex-shrink-0">
        <h2 className="text-white text-base font-medium text-center">
          Выбери тип игры и настрой фильтры
        </h2>
      </div>
      
      {/* Game Type Buttons */}
      <div className="px-4 pb-3 space-y-3 flex-shrink-0">
        <div className="grid grid-cols-4 gap-2">
          <button
            onClick={() => setGameType('singles')}
            className={`py-2 text-xs font-medium transition-colors ${
              gameType === 'singles'
                ? 'text-lime-400 underline'
                : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            Одиночная
          </button>
          <button
            onClick={() => setGameType('doubles')}
            className={`py-2 text-xs font-medium transition-colors ${
              gameType === 'doubles'
                ? 'text-lime-400 underline'
                : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            Парная
          </button>
          <button
            onClick={() => setGameType('training')}
            className={`py-2 text-xs font-medium transition-colors ${
              gameType === 'training'
                ? 'text-lime-400 underline'
                : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            Тренировка
          </button>
          <button
            onClick={() => setGameType('tournament')}
            className={`py-2 text-xs font-medium transition-colors ${
              gameType === 'tournament'
                ? 'text-lime-400 underline'
                : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            Турнир
          </button>
        </div>

        {/* Filters Button */}
        <div>
          <button
            onClick={() => setShowFilters(true)}
            disabled={!gameType}
            className={`text-sm font-medium transition-colors ${
              gameType
                ? 'text-lime-400 hover:text-lime-500'
                : 'text-gray-600 cursor-not-allowed'
            }`}
          >
            Фильтры
          </button>
        </div>
      </div>

      {/* Create Request Button - по центру экрана */}
      <div className="px-4 pb-3 flex-shrink-0">
        <button 
          onClick={() => setShowCreateRequest(true)}
          className="w-full bg-lime-500 hover:bg-lime-600 text-white py-3 rounded-lg font-medium transition-colors shadow-lg"
        >
          Создать заявку
        </button>
      </div>

      {/* Game Requests List */}
      {!gameType ? (
        <div className="flex-1 flex items-center justify-center px-6">
          <div className="text-center space-y-3">
            <div className="text-5xl">🎾</div>
            <p className="text-gray-400 text-sm">Выберите тип игры, чтобы увидеть заявки</p>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto px-4 pb-4">
          <div className="space-y-3">
            {gameRequests
              .filter(req => req.type === gameType)
              .map((request) => (
                <div
                  key={request.id}
                  className="bg-[#2a2a2a] rounded-lg p-3 min-h-[112px] flex flex-col justify-between"
                >
                  <div className="flex justify-between items-start mb-1.5">
                    <div>
                      <h3 className="text-white text-sm font-medium">{request.player}</h3>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-gray-400 text-xs">Уровень</span>
                      <span className="text-lime-500 font-bold text-base">{request.level}</span>
                    </div>
                  </div>
                  
                  {/* Participant Circles */}
                  <div className="my-1.5">
                    <ParticipantCircles participants={request.participants} maxParticipants={request.maxParticipants} />
                  </div>
                  
                  <div className="space-y-0.5">
                    <p className="text-gray-300 text-xs">📍 {request.court} • 📅 {request.date} • ⏱️ {request.time}-{calculateEndTime(request.time, request.duration)}</p>
                    <p className="text-gray-300 text-xs">🎯 {request.seekingLevelRange[0]} - {request.seekingLevelRange[1]}</p>
                    {request.comment && (
                      <p className="text-gray-400 text-xs italic">{request.comment}</p>
                    )}
                  </div>
                  
                  <button className="mt-2 w-full bg-lime-500 hover:bg-lime-600 text-white py-1.5 rounded-lg text-xs font-medium transition-colors">
                    Откликнуться
                  </button>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}

export function CourtsPage() {
  const [activeTab, setActiveTab] = useState('list');

  return (
    <div className="flex-1 overflow-y-auto overflow-x-hidden pb-20">
      <div className="px-4 py-3 space-y-4">
        {/* Tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('list')}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'list'
                ? 'bg-lime-500 text-white'
                : 'bg-[#2a2a2a] text-gray-400 hover:bg-[#333333]'
            }`}
          >
            писок кортов
          </button>
          <button
            onClick={() => setActiveTab('map')}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'map'
                ? 'bg-lime-500 text-white'
                : 'bg-[#2a2a2a] text-gray-400 hover:bg-[#333333]'
            }`}
          >
            Ката кортов
          </button>
        </div>

        {/* Content */}
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center space-y-3 px-6">
            <div className="text-5xl">🎾</div>
            <p className="text-gray-400 text-sm leading-relaxed">
              В скором времени здесь появится список всех платных и бесплатных кортов
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

interface HomePageProps {
  onUploadPhoto: () => void;
  onOpenSettings: () => void;
}

export function HomePage({ onUploadPhoto, onOpenSettings }: HomePageProps) {
  return (
    <div className="flex-1 overflow-hidden pb-20">
      {/* Player Photo with buttons - 40% экрана (341px) */}
      <div className="w-full h-[341px] relative">
        <img
          src="https://images.unsplash.com/photo-1723980839982-0c49951e7dba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZW5uaXMlMjBwbGF5ZXIlMjByYWNrZXR8ZW58MXx8fHwxNzY4OTc3Njg3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Player"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a] via-transparent to-transparent" />
        
        {/* Buttons on top of image - уменьшены на 20% */}
        <div className="absolute top-4 left-0 right-0 px-4 flex items-center justify-between">
          {/* Plus Button */}
          <button
            onClick={onUploadPhoto}
            className="w-10 h-10 rounded-lg bg-lime-500/80 hover:bg-lime-600 backdrop-blur-sm flex items-center justify-center transition-colors shadow-lg"
          >
            <Plus className="w-5 h-5 text-white" />
          </button>

          {/* Settings Button - только иконка */}
          <button
            onClick={onOpenSettings}
            className="w-10 h-10 rounded-lg bg-[#2a2a2a]/80 hover:bg-[#333333] backdrop-blur-sm flex items-center justify-center transition-colors shadow-lg"
          >
            <Settings className="w-5 h-5 text-gray-400" />
          </button>
        </div>
        
        {/* Rating and Location on image - внизу картинки */}
        <div className="absolute bottom-3 left-4 right-4">
          <div className="space-y-0.5">
            <div className="flex items-baseline gap-2">
              <span className="text-base text-gray-300">Рейтинг</span>
              <span className="text-base font-bold text-white">1548</span>
            </div>
            <div className="text-gray-300 text-sm">
              <p>Нью-Йор, США</p>
            </div>
          </div>
        </div>
      </div>

      {/* Player Info - оптимизированы размеры для видимости всей статистики */}
      <div className="px-4 py-2 space-y-2">
        {/* Rating History Chart - уменьшен */}
        <div className="space-y-1">
          <h3 className="text-white text-sm font-medium">История рейтинга</h3>
          <div className="bg-[#2a2a2a] rounded-lg p-2">
            <div className="h-24">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={ratingData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                  <XAxis
                    dataKey="month"
                    stroke="#6b7280"
                    style={{ fontSize: '10px' }}
                    tickMargin={5}
                  />
                  <YAxis
                    stroke="#6b7280"
                    style={{ fontSize: '10px' }}
                    domain={[1400, 1600]}
                    tickMargin={5}
                    width={40}
                  />
                  <Line
                    type="monotone"
                    dataKey="rating"
                    stroke="#10b981"
                    strokeWidth={2.5}
                    dot={{ fill: '#10b981', r: 3 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Last Games - компактнее */}
        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <h3 className="text-white text-sm font-medium">Последние игры</h3>
            <button className="bg-[#2a2a2a] hover:bg-[#333333] rounded px-2 py-0.5 text-white text-[9px] transition-colors">
              Посмотреть все
            </button>
          </div>
          <div className="space-y-1.5">
            {/* Первая игра */}
            <div className="bg-[#2a2a2a] rounded-lg p-2">
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-white text-[11px] font-medium">
                    {lastGames[0].player1} vs {lastGames[0].player2}
                  </div>
                  <div className="text-gray-400 text-[9px] mt-0.5">
                    {lastGames[0].date} • {lastGames[0].time}
                  </div>
                </div>
                <div className="text-emerald-400 font-semibold text-xs">
                  {lastGames[0].score}
                </div>
              </div>
            </div>
            
            {/* Вторая игра */}
            <div className="bg-[#2a2a2a] rounded-lg p-2">
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-white text-[11px] font-medium">
                    {lastGames[1].player1} vs {lastGames[1].player2}
                  </div>
                  <div className="text-gray-400 text-[9px] mt-0.5">
                    {lastGames[1].date} • {lastGames[1].time}
                  </div>
                </div>
                <div className="text-emerald-400 font-semibold text-xs">
                  {lastGames[1].score}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Statistics - теперь полностью видна */}
        <div className="space-y-1">
          <h3 className="text-white text-sm font-medium">Статистика</h3>
          <div className="bg-[#2a2a2a] rounded-lg p-2.5">
            <div className="grid grid-cols-3 gap-3 text-center">
              <div>
                <div className="text-white font-semibold text-lg">{stats.won}</div>
                <div className="text-gray-400 text-[9px]">Побед</div>
              </div>
              <div>
                <div className="text-white font-semibold text-lg">{stats.lost}</div>
                <div className="text-gray-400 text-[9px]">Поражений</div>
              </div>
              <div>
                <div className="text-emerald-400 font-bold text-lg">{stats.winPercentage}%</div>
                <div className="text-gray-400 text-[9px]">Процент побед</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}