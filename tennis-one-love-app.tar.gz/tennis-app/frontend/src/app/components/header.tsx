import { Plus, Settings } from 'lucide-react';

interface HeaderProps {
  onUploadPhoto: () => void;
  onOpenSettings: () => void;
}

export function Header({ onUploadPhoto, onOpenSettings }: HeaderProps) {
  return (
    <div className="w-full bg-[#2a2a2a] px-4 py-3 flex items-center justify-between">
      {/* Left: Plus Button */}
      <button
        onClick={onUploadPhoto}
        className="w-10 h-10 rounded-lg bg-lime-500 hover:bg-lime-600 flex items-center justify-center transition-colors"
      >
        <Plus className="w-6 h-6 text-white" />
      </button>

      {/* Right: Settings Button */}
      <button
        onClick={onOpenSettings}
        className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[#1a1a1a] hover:bg-[#333333] transition-colors"
      >
        <Settings className="w-5 h-5 text-gray-400" />
        <span className="text-sm text-gray-400">Настройки</span>
      </button>
    </div>
  );
}
