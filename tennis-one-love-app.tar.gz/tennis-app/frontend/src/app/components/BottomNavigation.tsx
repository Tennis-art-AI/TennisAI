import { Trophy, Users, MapPin, Home } from 'lucide-react';
import { useTelegram } from '../hooks/useTelegram';

type TabType = 'rating' | 'tournaments' | 'play' | 'courts' | 'home';

interface BottomNavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

const tabs: Array<{
  id: TabType;
  label: string;
  icon: typeof Trophy | null;
}> = [
  { id: 'rating', label: 'Рейтинг', icon: Trophy },
  { id: 'tournaments', label: 'Турниры', icon: Users },
  { id: 'play', label: 'Играть', icon: null }, // Специальная кнопка с теннисным мячом
  { id: 'courts', label: 'Корты', icon: MapPin },
  { id: 'home', label: 'Профиль', icon: Home },
];

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const { colorScheme } = useTelegram();
  
  const bgColor = colorScheme === 'dark' ? 'bg-[#2a2a2a]' : 'bg-white';
  const activeColor = colorScheme === 'dark' ? 'text-white' : 'text-gray-900';
  const inactiveColor = colorScheme === 'dark' ? 'text-gray-500' : 'text-gray-400';

  return (
    <nav className={`${bgColor} shadow-lg border-t border-gray-800/50`}>
      <div className="px-2 py-2 pb-[env(safe-area-inset-bottom)]">
        <div className="flex items-center justify-around relative">
          {tabs.map((tab) => {
            // Специальная кнопка "Играть" с теннисным мячом
            if (tab.id === 'play') {
              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className="flex flex-col items-center justify-center relative -top-4"
                  aria-label={tab.label}
                >
                  {/* Зелёный теннисный мяч */}
                  <div className={`
                    w-14 h-14 rounded-full shadow-lg flex items-center justify-center relative overflow-hidden
                    bg-gradient-to-br from-lime-400 via-lime-500 to-lime-600
                    active:scale-95 transition-transform
                    ${activeTab === 'play' ? 'ring-2 ring-lime-300 ring-offset-2 ring-offset-[#2a2a2a]' : ''}
                  `}>
                    {/* Реалистичные швы теннисного мяча */}
                    <svg viewBox="0 0 56 56" className="w-full h-full absolute inset-0">
                      {/* Левая изогнутая линия */}
                      <path
                        d="M 7 28 Q 14 14, 28 7"
                        fill="none"
                        stroke="white"
                        strokeWidth="2"
                        strokeLinecap="round"
                        opacity="0.85"
                      />
                      {/* Правая изогнутая линия */}
                      <path
                        d="M 28 49 Q 42 42, 49 28"
                        fill="none"
                        stroke="white"
                        strokeWidth="2"
                        strokeLinecap="round"
                        opacity="0.85"
                      />
                    </svg>
                  </div>
                  <span className={`text-[10px] mt-1 ${activeTab === 'play' ? activeColor : inactiveColor}`}>
                    {tab.label}
                  </span>
                </button>
              );
            }

            const Icon = tab.icon!;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`
                  flex flex-col items-center justify-center gap-0.5 py-1 px-3 min-w-[56px]
                  active:scale-95 transition-all
                `}
                aria-label={tab.label}
                aria-current={isActive ? 'page' : undefined}
              >
                <Icon
                  className={`w-5 h-5 transition-colors ${isActive ? activeColor : inactiveColor}`}
                  strokeWidth={isActive ? 2.5 : 2}
                />
                <span className={`text-[10px] transition-colors ${isActive ? activeColor : inactiveColor}`}>
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
