import { useState } from 'react';
import { useTelegram } from '@/hooks/useTelegram';
import { authApi } from '@/api';
import type { User } from '@/api';

interface AuthPageProps {
  onAuthComplete: (user: User, token: string) => void;
  error?: string | null;
  isTelegramApp: boolean;
}

export function AuthPage({ onAuthComplete, error, isTelegramApp }: AuthPageProps) {
  const { hapticFeedback } = useTelegram();
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [step, setStep] = useState<'initial' | 'code'>('initial');
  const [isLoading, setIsLoading] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);

  // Авторизация через Telegram
  const handleTelegramAuth = async () => {
    hapticFeedback('light');
    setIsLoading(true);
    setLocalError(null);
    
    try {
      const response = await authApi.loginTelegram();
      if (response.success) {
        hapticFeedback('success');
        onAuthComplete(response.user, response.token);
      }
    } catch (err: any) {
      hapticFeedback('error');
      setLocalError(err.response?.data?.message || 'Ошибка авторизации');
    } finally {
      setIsLoading(false);
    }
  };

  // Отправка кода на email
  const handleSendCode = async () => {
    if (!email || !email.includes('@')) {
      hapticFeedback('error');
      setLocalError('Введите корректный email');
      return;
    }
    
    hapticFeedback('light');
    setIsLoading(true);
    setLocalError(null);
    
    try {
      const response = await authApi.sendEmailCode(email);
      if (response.success) {
        hapticFeedback('success');
        setStep('code');
      }
    } catch (err: any) {
      hapticFeedback('error');
      setLocalError(err.response?.data?.message || 'Ошибка отправки кода');
    } finally {
      setIsLoading(false);
    }
  };

  // Проверка кода
  const handleVerifyCode = async () => {
    if (!code || code.length !== 6) {
      hapticFeedback('error');
      setLocalError('Введите 6-значный код');
      return;
    }
    
    hapticFeedback('light');
    setIsLoading(true);
    setLocalError(null);
    
    try {
      const response = await authApi.verifyEmailCode(email, code);
      if (response.success) {
        hapticFeedback('success');
        onAuthComplete(response.user, response.token);
      }
    } catch (err: any) {
      hapticFeedback('error');
      setLocalError(err.response?.data?.message || 'Неверный код');
    } finally {
      setIsLoading(false);
    }
  };

  const displayError = localError || error;

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a]">
      <div className="relative overflow-hidden" style={{ width: '393px', height: '852px' }}>
        {/* Background - Tennis Court */}
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1554068865-24cecd4e34b8?w=800)',
            backgroundPosition: 'center center',
            backgroundSize: 'cover'
          }}
        />
        
        {/* Dark Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/40 to-black/80" />

        {/* Content Container */}
        <div className="relative h-full flex flex-col items-center justify-between px-6 py-8">
          
          {/* Top Section: Logo & Title */}
          <div className="text-center mt-12">
            {/* Tennis Ball Logo */}
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-lime-400 via-lime-500 to-lime-600 shadow-lg relative overflow-hidden">
              <svg viewBox="0 0 64 64" className="w-full h-full">
                <path
                  d="M 8 32 Q 16 16, 32 8"
                  fill="none"
                  stroke="white"
                  strokeWidth="3"
                  strokeLinecap="round"
                  opacity="0.9"
                />
                <path
                  d="M 32 56 Q 48 48, 56 32"
                  fill="none"
                  stroke="white"
                  strokeWidth="3"
                  strokeLinecap="round"
                  opacity="0.9"
                />
              </svg>
            </div>
            <h1 className="text-4xl font-bold text-white tracking-wide drop-shadow-2xl">
              Tennis One Love
            </h1>
            <p className="text-gray-300 mt-2 text-sm">
              Найди партнёра для игры
            </p>
          </div>

          {/* Auth Form Section */}
          <div className="w-full space-y-4">
            {/* Error Message */}
            {displayError && (
              <div className="bg-red-500/20 border border-red-500/50 rounded-lg px-4 py-3 text-red-200 text-sm text-center">
                {displayError}
              </div>
            )}

            {step === 'initial' ? (
              <>
                {/* Telegram Auth Button - только если в Telegram */}
                {isTelegramApp && (
                  <>
                    <button
                      onClick={handleTelegramAuth}
                      disabled={isLoading}
                      className="w-full bg-[#0088cc] hover:bg-[#0077b3] disabled:opacity-50 text-white py-4 rounded-xl font-medium transition-colors flex items-center justify-center gap-3 shadow-xl"
                    >
                      <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        className="flex-shrink-0"
                      >
                        <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295-.002 0-.003 0-.005 0l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.869 4.326-2.96-.924c-.64-.203-.654-.64.135-.954l11.566-4.458c.538-.196 1.006.128.832.941z" />
                      </svg>
                      {isLoading ? 'Авторизация...' : 'Войти через Telegram'}
                    </button>
                    
                    {/* Divider */}
                    <div className="flex items-center gap-4">
                      <div className="flex-1 h-px bg-white/20" />
                      <span className="text-white/50 text-sm">или</span>
                      <div className="flex-1 h-px bg-white/20" />
                    </div>
                  </>
                )}

                {/* Email Input */}
                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm text-white/80 pl-1 font-medium">
                    Войти по E-mail
                  </label>
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    disabled={isLoading}
                    className="w-full bg-white/10 backdrop-blur-md text-white px-4 py-4 rounded-xl border border-white/20 focus:border-lime-400 focus:bg-white/15 focus:outline-none transition-all placeholder:text-white/40 disabled:opacity-50"
                  />
                </div>

                {/* Submit Button */}
                <button
                  onClick={handleSendCode}
                  disabled={isLoading || !email}
                  className="w-full bg-lime-500 hover:bg-lime-600 disabled:opacity-50 disabled:hover:bg-lime-500 text-white py-4 rounded-xl font-semibold transition-colors shadow-xl"
                >
                  {isLoading ? 'Отправка...' : 'Получить код'}
                </button>
              </>
            ) : (
              <>
                {/* Back Button */}
                <button
                  onClick={() => {
                    hapticFeedback('light');
                    setStep('initial');
                    setCode('');
                    setLocalError(null);
                  }}
                  className="text-white/70 hover:text-white text-sm flex items-center gap-2 transition-colors"
                >
                  ← Назад
                </button>

                {/* Code Input */}
                <div className="space-y-2">
                  <label className="text-sm text-white/80 pl-1 font-medium">
                    Код отправлен на {email}
                  </label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    placeholder="000000"
                    maxLength={6}
                    disabled={isLoading}
                    className="w-full bg-white/10 backdrop-blur-md text-white text-center text-2xl tracking-[0.5em] px-4 py-4 rounded-xl border border-white/20 focus:border-lime-400 focus:bg-white/15 focus:outline-none transition-all placeholder:text-white/40 placeholder:tracking-[0.5em] disabled:opacity-50"
                  />
                </div>

                {/* Verify Button */}
                <button
                  onClick={handleVerifyCode}
                  disabled={isLoading || code.length !== 6}
                  className="w-full bg-lime-500 hover:bg-lime-600 disabled:opacity-50 disabled:hover:bg-lime-500 text-white py-4 rounded-xl font-semibold transition-colors shadow-xl"
                >
                  {isLoading ? 'Проверка...' : 'Подтвердить'}
                </button>

                {/* Resend Code */}
                <button
                  onClick={handleSendCode}
                  disabled={isLoading}
                  className="w-full text-lime-400 hover:text-lime-300 text-sm transition-colors"
                >
                  Отправить код повторно
                </button>
              </>
            )}
          </div>

          {/* Footer */}
          <div className="text-center pb-4">
            <p className="text-xs text-white/50">
              Входя в приложение, вы соглашаетесь с{' '}
              <button className="text-lime-400 hover:text-lime-300 transition-colors font-medium">
                условиями использования
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
