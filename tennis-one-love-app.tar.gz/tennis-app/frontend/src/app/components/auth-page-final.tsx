/**
 * AUTH PAGE - FINAL VERSION
 * Tennis One Love - Telegram Mini App
 * 
 * Размер: 393×852 пикселя (стандарт Telegram Mini App)
 * Дата сохранения: 23 января 2026
 * 
 * Описание макета:
 * - Фон: Травяной теннисный корт с градиентным затемнением
 * - Заголовок: "Tennis one love" (вверху)
 * - Кнопка Telegram: синяя (#0088cc)
 * - Поле Email: полупрозрачное с фокусом
 * - Кнопка авторизации: яркая салатовая (lime-500)
 * - Футер: текст с условиями использования (внизу)
 */

import courtBackground from 'figma:asset/fcb844ec7ee47b19ad88b3926c0b6ef98317e729.png';

export function AuthPageFinal({ onAuthComplete }: { onAuthComplete: () => void }) {
  return (
    <div className="relative overflow-hidden mx-auto" style={{ width: '393px', height: '852px' }}>
      {/* Background - Clean Tennis Court Grass */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${courtBackground})`,
          backgroundPosition: 'center center',
          backgroundSize: 'cover'
        }}
      />
      
      {/* Dark Gradient Overlay - уменьшенное затемнение */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/25 to-black/60" />

      {/* Content Container */}
      <div className="relative h-full flex flex-col items-center justify-between px-6 py-6">
        
        {/* Top Section: Title */}
        <div className="text-center mt-8">
          <h1 className="text-4xl font-bold text-white tracking-wide drop-shadow-2xl">Tennis one love</h1>
        </div>

        {/* Auth Form Section - centered */}
        <div className="w-full space-y-5">
          {/* Subtitle */}
          <p className="text-base text-white/95 text-center drop-shadow-lg font-medium mb-6">Выбери способ авторизации</p>

          {/* Telegram Auth Button */}
          <button
            onClick={onAuthComplete}
            className="w-full bg-[#0088cc] hover:bg-[#0077b3] text-white py-4 rounded-lg font-medium transition-colors flex items-center justify-center gap-3 shadow-xl"
          >
            <svg
              width="22"
              height="22"
              viewBox="0 0 24 24"
              fill="currentColor"
              className="flex-shrink-0"
            >
              <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295-.002 0-.003 0-.005 0l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.869 4.326-2.96-.924c-.64-.203-.654-.64.135-.954l11.566-4.458c.538-.196 1.006.128.832.941z" />
            </svg>
            Войти через Telegram
          </button>

          {/* Email Input */}
          <div className="space-y-2">
            <label htmlFor="email" className="text-xs text-white/80 pl-1 font-medium">
              Ввести E-mail
            </label>
            <input
              id="email"
              type="email"
              placeholder="tennis@gmail.com"
              className="w-full bg-white/15 backdrop-blur-md text-white px-4 py-4 rounded-lg border border-white/30 focus:border-lime-400 focus:bg-white/20 focus:outline-none transition-all placeholder:text-white/50 shadow-lg"
            />
          </div>

          {/* Green Auth Button - яркая салатовая кнопка */}
          <button
            onClick={onAuthComplete}
            className="w-full bg-lime-500 hover:bg-lime-600 text-white py-4 rounded-lg font-semibold transition-colors shadow-xl"
          >
            Авторизоваться
          </button>
        </div>

        {/* Footer - positioned at bottom */}
        <div className="text-center pb-6">
          <p className="text-xs text-white/60">
            Входя в приложение, вы соглашаетесь с{' '}
            <button className="text-lime-400 hover:text-lime-300 transition-colors font-medium">
              условиями использования
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
