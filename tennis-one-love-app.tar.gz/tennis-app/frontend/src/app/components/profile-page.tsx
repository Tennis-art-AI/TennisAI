import { LineChart, Line, ResponsiveContainer, XAxis, YAxis } from 'recharts';

const ratingData = [
  { month: 'Jan', rating: 1420 },
  { month: 'Feb', rating: 1450 },
  { month: 'Mar', rating: 1480 },
  { month: 'Apr', rating: 1465 },
  { month: 'May', rating: 1510 },
  { month: 'Jun', rating: 1548 },
];

const lastGames = [
  { opponent: 'Alex Morgan', score: '6:2, 6:3', date: 'Jan 18, 2026', time: '14:30' },
  { opponent: 'Jordan Lee', score: '7:5, 3:6, 6:4', date: 'Jan 15, 2026', time: '10:00' },
  { opponent: 'Sam Taylor', score: '6:4, 6:2', date: 'Jan 12, 2026', time: '16:45' },
];

const stats = {
  won: 30,
  lost: 7,
  total: 37,
  winPercentage: 81,
};

export function ProfilePage() {
  return (
    <div className="flex-1 overflow-hidden pb-20">
      {/* Player Photo - back to original size */}
      <div className="w-full h-44 relative">
        <img
          src="https://images.unsplash.com/photo-1723980839982-0c49951e7dba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZW5uaXMlMjBwbGF5ZXIlMjByYWNrZXR8ZW58MXx8fHwxNzY4OTc3Njg3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Player"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a] to-transparent" />
      </div>

      {/* Player Info - reduced spacing and sizes */}
      <div className="px-4 py-3 space-y-4">
        {/* Rating Section */}
        <div className="space-y-1">
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-white">1548</span>
            <span className="text-sm text-gray-400">Rating</span>
          </div>
          <div className="text-gray-400 text-sm">
            <p>New York, USA</p>
          </div>
        </div>

        {/* Rating History Chart - reduced height */}
        <div className="space-y-2">
          <h3 className="text-white text-sm">Rating History</h3>
          <div className="bg-[#2a2a2a] rounded-lg p-2 h-28">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={ratingData}>
                <XAxis
                  dataKey="month"
                  stroke="#6b7280"
                  style={{ fontSize: '10px' }}
                />
                <YAxis
                  stroke="#6b7280"
                  style={{ fontSize: '10px' }}
                  domain={[1400, 1600]}
                />
                <Line
                  type="monotone"
                  dataKey="rating"
                  stroke="#10b981"
                  strokeWidth={2}
                  dot={{ fill: '#10b981', r: 3 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Last Games - 1 game with small button on the side */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-white text-sm">Last Games</h3>
            <button className="bg-[#2a2a2a] hover:bg-[#333333] rounded px-2 py-1 text-white text-[10px] transition-colors">
              Посмотреть все
            </button>
          </div>
          <div className="bg-[#2a2a2a] rounded-lg p-3">
            <div className="flex justify-between items-start">
              <div>
                <div className="text-white text-xs font-medium">vs {lastGames[0].opponent}</div>
                <div className="text-gray-400 text-[10px]">{lastGames[0].date} • {lastGames[0].time}</div>
              </div>
              <div className="text-emerald-400 font-semibold text-sm">
                {lastGames[0].score}
              </div>
            </div>
          </div>
        </div>

        {/* Statistics - more compact */}
        <div className="space-y-2">
          <h3 className="text-white text-sm">Statistics</h3>
          <div className="bg-[#2a2a2a] rounded-lg p-3">
            <div className="grid grid-cols-3 gap-3 text-center">
              <div>
                <div className="text-white font-semibold text-lg">{stats.won}</div>
                <div className="text-gray-400 text-[10px]">Won</div>
              </div>
              <div>
                <div className="text-white font-semibold text-lg">{stats.lost}</div>
                <div className="text-gray-400 text-[10px]">Lost</div>
              </div>
              <div>
                <div className="text-emerald-400 font-bold text-lg">{stats.winPercentage}%</div>
                <div className="text-gray-400 text-[10px]">Win Rate</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}