import { User, Trophy, Home, MapPin } from 'lucide-react';

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const tabs = [
    { id: 'rating', label: 'Рейтинг', icon: Trophy },
    { id: 'profile', label: 'Турниры', icon: User },
    { id: 'play', label: 'Играть', icon: null }, // Special tennis ball button
    { id: 'courts', label: 'Корты', icon: MapPin },
    { id: 'home', label: 'Профиль', icon: Home },
  ];

  return (
    <div className="bg-[#2a2a2a] shadow-lg absolute bottom-0 left-0 right-0">
      <div className="px-2 py-3">
        <div className="flex items-center justify-around relative">
          {tabs.map((tab) => {
            if (tab.id === 'play') {
              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className="flex flex-col items-center justify-center relative -top-6"
                >
                  {/* Green Tennis Ball Button with realistic lines */}
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-lime-400 via-lime-500 to-lime-600 shadow-lg flex items-center justify-center relative overflow-hidden">
                    {/* Realistic tennis ball seam lines */}
                    <div className="absolute inset-0">
                      <svg viewBox="0 0 64 64" className="w-full h-full">
                        {/* Left curved line */}
                        <path
                          d="M 8 32 Q 16 16, 32 8"
                          fill="none"
                          stroke="white"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                          opacity="0.9"
                        />
                        {/* Right curved line (mirror of left) */}
                        <path
                          d="M 32 56 Q 48 48, 56 32"
                          fill="none"
                          stroke="white"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                          opacity="0.9"
                        />
                      </svg>
                    </div>
                  </div>
                  <span className="text-xs text-gray-400 mt-1">{tab.label}</span>
                </button>
              );
            }

            const Icon = tab.icon!;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className="flex flex-col items-center justify-center gap-1 py-1 px-3 min-w-[60px]"
              >
                <Icon
                  className={`w-6 h-6 ${
                    isActive ? 'text-white' : 'text-gray-500'
                  }`}
                />
                <span
                  className={`text-xs ${
                    isActive ? 'text-white' : 'text-gray-500'
                  }`}
                >
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}