import { useState } from 'react';
import { ChevronLeft, User, Bell, Shield, Palette, LogOut, ChevronRight, Moon, Sun } from 'lucide-react';
import { useTelegram } from '@/hooks/useTelegram';
import { useAuthStore } from '@/store';

interface SettingsPageProps {
  onBack: () => void;
}

export function SettingsPage({ onBack }: SettingsPageProps) {
  const { hapticFeedback, showConfirm, colorScheme } = useTelegram();
  const { user, logout } = useAuthStore();
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(colorScheme === 'dark');

  const handleLogout = async () => {
    hapticFeedback('light');
    const confirmed = await showConfirm('Вы уверены, что хотите выйти?');
    if (confirmed) {
      hapticFeedback('success');
      logout();
    }
  };

  const handleToggleNotifications = () => {
    hapticFeedback('selection');
    setNotifications(!notifications);
  };

  const handleToggleDarkMode = () => {
    hapticFeedback('selection');
    setDarkMode(!darkMode);
  };

  const settingsSections = [
    {
      title: 'Аккаунт',
      items: [
        {
          icon: User,
          label: 'Редактировать профиль',
          value: user?.firstName || 'Игрок',
          onClick: () => {
            hapticFeedback('light');
            // TODO: Navigate to edit profile
          },
        },
      ],
    },
    {
      title: 'Уведомления',
      items: [
        {
          icon: Bell,
          label: 'Push-уведомления',
          toggle: true,
          value: notifications,
          onClick: handleToggleNotifications,
        },
      ],
    },
    {
      title: 'Внешний вид',
      items: [
        {
          icon: darkMode ? Moon : Sun,
          label: 'Тёмная тема',
          toggle: true,
          value: darkMode,
          onClick: handleToggleDarkMode,
        },
      ],
    },
    {
      title: 'Безопасность',
      items: [
        {
          icon: Shield,
          label: 'Политика конфиденциальности',
          onClick: () => {
            hapticFeedback('light');
            // TODO: Open privacy policy
          },
        },
      ],
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto pb-20 bg-[#1a1a1a]">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-[#1a1a1a] border-b border-white/10">
        <div className="flex items-center gap-3 px-4 py-4">
          <button
            onClick={() => {
              hapticFeedback('light');
              onBack();
            }}
            className="w-10 h-10 rounded-full bg-[#2a2a2a] flex items-center justify-center hover:bg-[#333333] transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-white" />
          </button>
          <h1 className="text-xl font-semibold text-white">Настройки</h1>
        </div>
      </div>

      {/* User Info Card */}
      <div className="px-4 py-4">
        <div className="bg-[#2a2a2a] rounded-2xl p-4 flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-lime-500 flex items-center justify-center text-white text-2xl font-bold">
            {user?.firstName?.[0] || 'T'}
          </div>
          <div className="flex-1">
            <div className="text-white font-semibold text-lg">
              {user?.firstName || 'Теннисист'} {user?.lastName || ''}
            </div>
            {user?.username && (
              <div className="text-gray-400 text-sm">@{user.username}</div>
            )}
            <div className="text-lime-400 text-sm mt-1">
              Рейтинг: {user?.rating || 1500}
            </div>
          </div>
        </div>
      </div>

      {/* Settings Sections */}
      <div className="px-4 space-y-6">
        {settingsSections.map((section, sectionIndex) => (
          <div key={sectionIndex}>
            <h2 className="text-gray-500 text-xs uppercase tracking-wider mb-2 px-1">
              {section.title}
            </h2>
            <div className="bg-[#2a2a2a] rounded-2xl overflow-hidden">
              {section.items.map((item, itemIndex) => (
                <button
                  key={itemIndex}
                  onClick={item.onClick}
                  className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-white/5 transition-colors border-b border-white/5 last:border-b-0"
                >
                  <div className="w-9 h-9 rounded-full bg-[#3a3a3a] flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-gray-400" />
                  </div>
                  <span className="flex-1 text-left text-white">{item.label}</span>
                  {item.toggle ? (
                    <div
                      className={`w-12 h-7 rounded-full p-1 transition-colors ${
                        item.value ? 'bg-lime-500' : 'bg-gray-600'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                          item.value ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      {typeof item.value === 'string' && (
                        <span className="text-gray-400 text-sm">{item.value}</span>
                      )}
                      <ChevronRight className="w-5 h-5 text-gray-500" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        ))}

        {/* Logout Button */}
        <button
          onClick={handleLogout}
          className="w-full bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 rounded-2xl py-4 flex items-center justify-center gap-3 transition-colors"
        >
          <LogOut className="w-5 h-5 text-red-400" />
          <span className="text-red-400 font-medium">Выйти из аккаунта</span>
        </button>

        {/* App Version */}
        <div className="text-center py-4">
          <p className="text-gray-500 text-xs">Tennis One Love v1.0.0</p>
          <p className="text-gray-600 text-xs mt-1">© 2026 Tennis One Love</p>
        </div>
      </div>
    </div>
  );
}
