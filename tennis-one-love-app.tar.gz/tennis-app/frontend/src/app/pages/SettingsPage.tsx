import { ChevronRight, User, Bell, Shield, HelpCircle, LogOut, Moon, Sun } from 'lucide-react';
import { useTelegram } from '../hooks/useTelegram';
import { useAuthStore } from '../services/authStore';

interface SettingItem {
  id: string;
  icon: typeof User;
  label: string;
  description?: string;
  action: 'navigate' | 'toggle' | 'danger';
}

const settingsItems: SettingItem[] = [
  {
    id: 'profile',
    icon: User,
    label: 'Редактировать профиль',
    description: 'Имя, город, фото',
    action: 'navigate',
  },
  {
    id: 'notifications',
    icon: Bell,
    label: 'Уведомления',
    description: 'Настройка push-уведомлений',
    action: 'navigate',
  },
  {
    id: 'privacy',
    icon: Shield,
    label: 'Конфиденциальность',
    description: 'Настройки приватности',
    action: 'navigate',
  },
  {
    id: 'help',
    icon: HelpCircle,
    label: 'Помощь и поддержка',
    description: 'FAQ и связь с нами',
    action: 'navigate',
  },
];

export function SettingsPage() {
  const { colorScheme, hapticImpact, hapticNotification, showAlert, showConfirm } = useTelegram();
  const { user, logout } = useAuthStore();

  const bgCard = colorScheme === 'dark' ? 'bg-[#2a2a2a]' : 'bg-gray-100';

  const handleSettingClick = (item: SettingItem) => {
    hapticImpact('light');
    showAlert(`Раздел "${item.label}" будет доступен в следующей версии`);
  };

  const handleLogout = async () => {
    hapticImpact('medium');
    
    const confirmed = await showConfirm('Вы уверены, что хотите выйти?');
    
    if (confirmed) {
      hapticNotification('success');
      logout();
    }
  };

  return (
    <div className="flex-1 overflow-y-auto pb-20">
      <div className="px-4 py-4 space-y-4">
        {/* Заголовок */}
        <h2 className="text-white text-lg font-medium">Настройки</h2>

        {/* Профиль пользователя */}
        <div className={`${bgCard} rounded-lg p-4`}>
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 bg-lime-500 rounded-full flex items-center justify-center text-white text-xl font-bold">
              {user?.firstName?.charAt(0) || 'U'}
            </div>
            <div className="flex-1">
              <h3 className="text-white font-medium">
                {user?.firstName} {user?.lastName}
              </h3>
              <p className="text-gray-400 text-sm">
                {user?.username ? `@${user.username}` : user?.email || 'Telegram пользователь'}
              </p>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-lime-400 text-xs font-medium">
                  Рейтинг: {user?.rating || 1548}
                </span>
                {user?.city && (
                  <>
                    <span className="text-gray-600">•</span>
                    <span className="text-gray-400 text-xs">{user.city}</span>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Тема */}
        <div className={`${bgCard} rounded-lg p-3`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {colorScheme === 'dark' ? (
                <Moon className="w-5 h-5 text-gray-400" />
              ) : (
                <Sun className="w-5 h-5 text-yellow-400" />
              )}
              <div>
                <span className="text-white text-sm">Тема оформления</span>
                <p className="text-gray-500 text-xs">Синхронизирована с Telegram</p>
              </div>
            </div>
            <span className="text-gray-400 text-xs">
              {colorScheme === 'dark' ? 'Тёмная' : 'Светлая'}
            </span>
          </div>
        </div>

        {/* Список настроек */}
        <div className={`${bgCard} rounded-lg overflow-hidden`}>
          {settingsItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => handleSettingClick(item)}
                className={`w-full flex items-center justify-between p-3 hover:bg-[#333333] transition-colors active:bg-[#404040] ${
                  index !== settingsItems.length - 1 ? 'border-b border-gray-700/50' : ''
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-5 h-5 text-gray-400" />
                  <div className="text-left">
                    <span className="text-white text-sm">{item.label}</span>
                    {item.description && (
                      <p className="text-gray-500 text-xs">{item.description}</p>
                    )}
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-500" />
              </button>
            );
          })}
        </div>

        {/* Кнопка выхода */}
        <button
          onClick={handleLogout}
          className={`w-full ${bgCard} rounded-lg p-3 flex items-center gap-3 hover:bg-red-500/10 transition-colors active:scale-[0.98]`}
        >
          <LogOut className="w-5 h-5 text-red-400" />
          <span className="text-red-400 text-sm font-medium">Выйти из аккаунта</span>
        </button>

        {/* Версия приложения */}
        <div className="text-center pt-4">
          <p className="text-gray-600 text-xs">Tennis One Love</p>
          <p className="text-gray-700 text-[10px]">Версия 1.0.0</p>
        </div>
      </div>
    </div>
  );
}
