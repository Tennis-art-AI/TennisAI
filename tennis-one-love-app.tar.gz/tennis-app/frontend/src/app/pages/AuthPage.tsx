import { useState } from 'react';
import { useTelegram } from '../hooks/useTelegram';
import { useAuthStore } from '../services/authStore';

export function AuthPage() {
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [step, setStep] = useState<'initial' | 'code'>('initial');
  const [error, setError] = useState('');
  
  const { user, isTelegram, hapticImpact, hapticNotification } = useTelegram();
  const { setTelegramUser, requestEmailCode, loginWithEmail, isLoading } = useAuthStore();

  // Авторизация через Telegram
  const handleTelegramAuth = async () => {
    hapticImpact('medium');
    setError('');
    
    try {
      if (user) {
        await setTelegramUser(user);
        hapticNotification('success');
      } else if (!isTelegram) {
        // В режиме разработки создаём тестового пользователя
        await setTelegramUser({
          id: 123456789,
          first_name: 'Тестовый',
          last_name: 'Пользователь',
          username: 'testuser',
        });
        hapticNotification('success');
      }
    } catch (err) {
      hapticNotification('error');
      setError('Ошибка авторизации через Telegram');
    }
  };

  // Запрос кода на email
  const handleRequestCode = async () => {
    hapticImpact('light');
    setError('');
    
    if (!email || !email.includes('@')) {
      setError('Введите корректный email');
      hapticNotification('error');
      return;
    }

    try {
      await requestEmailCode(email);
      setStep('code');
      hapticNotification('success');
    } catch (err) {
      hapticNotification('error');
      setError('Ошибка отправки кода. Попробуйте позже.');
    }
  };

  // Подтверждение кода
  const handleVerifyCode = async () => {
    hapticImpact('light');
    setError('');
    
    if (!code || code.length !== 6) {
      setError('Введите 6-значный код');
      hapticNotification('error');
      return;
    }

    try {
      await loginWithEmail(email, code);
      hapticNotification('success');
    } catch (err) {
      hapticNotification('error');
      setError('Неверный код. Попробуйте ещё раз.');
    }
  };

  return (
    <div className="relative overflow-hidden w-full h-full max-w-[393px] max-h-[852px] mx-auto">
      {/* Фоновое изображение теннисного корта */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1554068865-24cecd4e34b8?w=800&q=80')`,
        }}
      />

      {/* Затемняющий градиент */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/30 to-black/70" />

      {/* Контент */}
      <div className="relative h-full flex flex-col items-center justify-between px-6 py-8">
        {/* Заголовок */}
        <div className="text-center mt-12">
          <h1 className="text-4xl font-bold text-white tracking-wide drop-shadow-2xl">
            Tennis One Love
          </h1>
          <p className="text-white/70 mt-2 text-sm">
            Найди партнёра для игры
          </p>
        </div>

        {/* Форма авторизации */}
        <div className="w-full space-y-4">
          {step === 'initial' ? (
            <>
              <p className="text-base text-white/90 text-center drop-shadow-lg font-medium mb-6">
                Выберите способ авторизации
              </p>

              {/* Кнопка авторизации через Telegram */}
              <button
                onClick={handleTelegramAuth}
                disabled={isLoading}
                className="w-full bg-[#0088cc] hover:bg-[#0077b3] disabled:opacity-50 text-white py-4 rounded-xl font-medium transition-colors flex items-center justify-center gap-3 shadow-xl active:scale-[0.98]"
              >
                <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295-.002 0-.003 0-.005 0l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.869 4.326-2.96-.924c-.64-.203-.654-.64.135-.954l11.566-4.458c.538-.196 1.006.128.832.941z" />
                </svg>
                {isLoading ? 'Загрузка...' : 'Войти через Telegram'}
              </button>

              {/* Разделитель */}
              <div className="flex items-center gap-3">
                <div className="flex-1 h-px bg-white/20" />
                <span className="text-white/50 text-sm">или</span>
                <div className="flex-1 h-px bg-white/20" />
              </div>

              {/* Поле ввода email */}
              <div className="space-y-2">
                <label htmlFor="email" className="text-xs text-white/70 pl-1 font-medium">
                  Войти по E-mail
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="tennis@gmail.com"
                  className="w-full bg-white/10 backdrop-blur-md text-white px-4 py-4 rounded-xl border border-white/20 focus:border-lime-400 focus:bg-white/15 focus:outline-none transition-all placeholder:text-white/40"
                />
              </div>

              {/* Кнопка получения кода */}
              <button
                onClick={handleRequestCode}
                disabled={isLoading || !email}
                className="w-full bg-lime-500 hover:bg-lime-600 disabled:opacity-50 text-white py-4 rounded-xl font-semibold transition-colors shadow-xl active:scale-[0.98]"
              >
                {isLoading ? 'Отправка...' : 'Получить код'}
              </button>
            </>
          ) : (
            <>
              <p className="text-base text-white/90 text-center drop-shadow-lg font-medium mb-2">
                Введите код из письма
              </p>
              <p className="text-sm text-white/60 text-center mb-6">
                Отправлено на {email}
              </p>

              {/* Поле ввода кода */}
              <input
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                placeholder="000000"
                className="w-full bg-white/10 backdrop-blur-md text-white text-center text-2xl tracking-[0.5em] px-4 py-4 rounded-xl border border-white/20 focus:border-lime-400 focus:bg-white/15 focus:outline-none transition-all placeholder:text-white/40"
              />

              {/* Кнопка подтверждения */}
              <button
                onClick={handleVerifyCode}
                disabled={isLoading || code.length !== 6}
                className="w-full bg-lime-500 hover:bg-lime-600 disabled:opacity-50 text-white py-4 rounded-xl font-semibold transition-colors shadow-xl active:scale-[0.98]"
              >
                {isLoading ? 'Проверка...' : 'Подтвердить'}
              </button>

              {/* Кнопка "Назад" */}
              <button
                onClick={() => {
                  setStep('initial');
                  setCode('');
                  setError('');
                }}
                className="w-full text-white/70 hover:text-white py-2 text-sm transition-colors"
              >
                ← Изменить email
              </button>
            </>
          )}

          {/* Ошибка */}
          {error && (
            <p className="text-red-400 text-sm text-center bg-red-500/10 rounded-lg py-2">
              {error}
            </p>
          )}
        </div>

        {/* Футер */}
        <div className="text-center pb-4">
          <p className="text-xs text-white/50">
            Входя в приложение, вы соглашаетесь с{' '}
            <button className="text-lime-400 hover:text-lime-300 transition-colors font-medium">
              условиями использования
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
