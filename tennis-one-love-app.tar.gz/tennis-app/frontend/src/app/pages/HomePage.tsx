import { Plus, Settings } from 'lucide-react';
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis } from 'recharts';
import { useTelegram } from '../hooks/useTelegram';
import { useAuthStore } from '../services/authStore';

interface HomePageProps {
  onOpenSettings: () => void;
}

// Тестовые данные для графика рейтинга
const ratingData = [
  { month: 'Янв', rating: 1420 },
  { month: 'Фев', rating: 1450 },
  { month: 'Мар', rating: 1480 },
  { month: 'Апр', rating: 1465 },
  { month: 'Май', rating: 1510 },
  { month: 'Июн', rating: 1548 },
];

// Тестовые данные последних игр
const lastGames = [
  {
    id: '1',
    opponent: 'Алекс Морган',
    score: '6:2, 6:3',
    date: '18 янв, 2026',
    time: '14:30',
    result: 'win' as const,
  },
  {
    id: '2',
    opponent: 'Джордан Ли',
    score: '7:5, 3:6, 6:4',
    date: '15 янв, 2026',
    time: '10:00',
    result: 'win' as const,
  },
];

// Тестовая статистика
const stats = {
  won: 30,
  lost: 7,
  winPercentage: 81,
};

export function HomePage({ onOpenSettings }: HomePageProps) {
  const { hapticImpact, showAlert, colorScheme } = useTelegram();
  const { user } = useAuthStore();

  const handleUploadPhoto = () => {
    hapticImpact('medium');
    showAlert('Загрузка фото будет доступна в следующей версии');
  };

  const handleSettings = () => {
    hapticImpact('light');
    onOpenSettings();
  };

  const handleViewAllGames = () => {
    hapticImpact('light');
    showAlert('Полный список игр будет доступен в следующей версии');
  };

  return (
    <div className="flex-1 overflow-y-auto overflow-x-hidden pb-20">
      {/* Фото игрока с кнопками */}
      <div className="w-full h-[320px] relative">
        <img
          src="https://images.unsplash.com/photo-1723980839982-0c49951e7dba?w=800&q=80"
          alt="Фото игрока"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a] via-transparent to-transparent" />

        {/* Кнопки поверх фото */}
        <div className="absolute top-4 left-0 right-0 px-4 flex items-center justify-between">
          {/* Кнопка добавления фото */}
          <button
            onClick={handleUploadPhoto}
            className="w-10 h-10 rounded-lg bg-lime-500/80 hover:bg-lime-600 backdrop-blur-sm flex items-center justify-center transition-colors shadow-lg active:scale-95"
            aria-label="Загрузить фото"
          >
            <Plus className="w-5 h-5 text-white" />
          </button>

          {/* Кнопка настроек */}
          <button
            onClick={handleSettings}
            className="w-10 h-10 rounded-lg bg-[#2a2a2a]/80 hover:bg-[#333333] backdrop-blur-sm flex items-center justify-center transition-colors shadow-lg active:scale-95"
            aria-label="Настройки"
          >
            <Settings className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Рейтинг и локация */}
        <div className="absolute bottom-3 left-4 right-4">
          <div className="space-y-0.5">
            <div className="flex items-baseline gap-2">
              <span className="text-base text-gray-300">Рейтинг</span>
              <span className="text-lg font-bold text-white">{user?.rating || 1548}</span>
            </div>
            <p className="text-gray-300 text-sm">{user?.city || 'Москва, Россия'}</p>
          </div>
        </div>
      </div>

      {/* Контент профиля */}
      <div className="px-4 py-3 space-y-3">
        {/* График истории рейтинга */}
        <section className="space-y-1.5">
          <h3 className="text-white text-sm font-medium">История рейтинга</h3>
          <div className={`rounded-lg p-2.5 ${colorScheme === 'dark' ? 'bg-[#2a2a2a]' : 'bg-gray-100'}`}>
            <div className="h-24">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={ratingData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                  <XAxis
                    dataKey="month"
                    stroke="#6b7280"
                    style={{ fontSize: '10px' }}
                    tickMargin={5}
                  />
                  <YAxis
                    stroke="#6b7280"
                    style={{ fontSize: '10px' }}
                    domain={[1400, 1600]}
                    tickMargin={5}
                    width={35}
                  />
                  <Line
                    type="monotone"
                    dataKey="rating"
                    stroke="#84cc16"
                    strokeWidth={2.5}
                    dot={{ fill: '#84cc16', r: 3 }}
                    activeDot={{ r: 5, fill: '#84cc16' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>

        {/* Последние игры */}
        <section className="space-y-1.5">
          <div className="flex items-center justify-between">
            <h3 className="text-white text-sm font-medium">Последние игры</h3>
            <button
              onClick={handleViewAllGames}
              className="bg-[#2a2a2a] hover:bg-[#333333] rounded px-2 py-0.5 text-white text-[10px] transition-colors active:scale-95"
            >
              Посмотреть все
            </button>
          </div>
          <div className="space-y-1.5">
            {lastGames.map((game) => (
              <div
                key={game.id}
                className={`rounded-lg p-2.5 ${colorScheme === 'dark' ? 'bg-[#2a2a2a]' : 'bg-gray-100'}`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <div className="text-white text-xs font-medium">
                      {user?.firstName || 'Иван'} vs {game.opponent}
                    </div>
                    <div className="text-gray-400 text-[10px] mt-0.5">
                      {game.date} • {game.time}
                    </div>
                  </div>
                  <div className={`font-semibold text-sm ${
                    game.result === 'win' ? 'text-emerald-400' : 'text-red-400'
                  }`}>
                    {game.score}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Статистика */}
        <section className="space-y-1.5">
          <h3 className="text-white text-sm font-medium">Статистика</h3>
          <div className={`rounded-lg p-3 ${colorScheme === 'dark' ? 'bg-[#2a2a2a]' : 'bg-gray-100'}`}>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div>
                <div className="text-white font-semibold text-xl">{stats.won}</div>
                <div className="text-gray-400 text-[10px]">Побед</div>
              </div>
              <div>
                <div className="text-white font-semibold text-xl">{stats.lost}</div>
                <div className="text-gray-400 text-[10px]">Поражений</div>
              </div>
              <div>
                <div className="text-lime-400 font-bold text-xl">{stats.winPercentage}%</div>
                <div className="text-gray-400 text-[10px]">Процент побед</div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
