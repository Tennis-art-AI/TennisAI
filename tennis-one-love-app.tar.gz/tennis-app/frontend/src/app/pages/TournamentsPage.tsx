import { useState } from 'react';
import { Calendar, MapPin, Users, Trophy, ChevronRight } from 'lucide-react';
import { useTelegram } from '../hooks/useTelegram';

interface Tournament {
  id: string;
  name: string;
  date: string;
  location: string;
  type: 'amateur' | 'pro' | 'mixed';
  participants: number;
  maxParticipants: number;
  prize?: string;
  status: 'upcoming' | 'ongoing' | 'finished';
  isRegistered: boolean;
}

// Тестовые данные турниров
const mockTournaments: Tournament[] = [
  {
    id: '1',
    name: 'Зимний кубок Москвы',
    date: '15-17 февраля 2026',
    location: 'ТЦ "Лужники"',
    type: 'amateur',
    participants: 24,
    maxParticipants: 32,
    prize: '50 000 ₽',
    status: 'upcoming',
    isRegistered: false,
  },
  {
    id: '2',
    name: 'Открытый турнир ЦСКА',
    date: '1-3 марта 2026',
    location: 'Корты ЦСКА',
    type: 'mixed',
    participants: 16,
    maxParticipants: 16,
    status: 'upcoming',
    isRegistered: true,
  },
  {
    id: '3',
    name: 'Весенний челлендж',
    date: '20-22 марта 2026',
    location: 'ТК "Динамо"',
    type: 'amateur',
    participants: 8,
    maxParticipants: 24,
    prize: '30 000 ₽',
    status: 'upcoming',
    isRegistered: false,
  },
];

type FilterType = 'all' | 'upcoming' | 'registered';

export function TournamentsPage() {
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const [tournaments] = useState<Tournament[]>(mockTournaments);
  
  const { colorScheme, hapticImpact, hapticNotification, showAlert, showConfirm } = useTelegram();

  const bgCard = colorScheme === 'dark' ? 'bg-[#2a2a2a]' : 'bg-gray-100';

  const handleFilterChange = (filter: FilterType) => {
    hapticImpact('light');
    setActiveFilter(filter);
  };

  const handleRegister = async (tournament: Tournament) => {
    hapticImpact('medium');
    
    if (tournament.participants >= tournament.maxParticipants) {
      hapticNotification('error');
      showAlert('К сожалению, все места заняты');
      return;
    }

    const confirmed = await showConfirm(
      `Зарегистрироваться на турнир "${tournament.name}"?`
    );

    if (confirmed) {
      hapticNotification('success');
      showAlert('Вы успешно зарегистрированы! Подробности отправлены в Telegram.');
    }
  };

  const handleViewDetails = (tournament: Tournament) => {
    hapticImpact('light');
    showAlert(`Подробная информация о турнире "${tournament.name}" будет доступна в следующей версии`);
  };

  const getTypeLabel = (type: Tournament['type']) => {
    switch (type) {
      case 'amateur':
        return 'Любительский';
      case 'pro':
        return 'Профессиональный';
      case 'mixed':
        return 'Смешанный';
    }
  };

  const getStatusLabel = (status: Tournament['status']) => {
    switch (status) {
      case 'upcoming':
        return 'Скоро';
      case 'ongoing':
        return 'Идёт';
      case 'finished':
        return 'Завершён';
    }
  };

  const filteredTournaments = tournaments.filter((t) => {
    if (activeFilter === 'registered') return t.isRegistered;
    if (activeFilter === 'upcoming') return t.status === 'upcoming';
    return true;
  });

  return (
    <div className="flex-1 overflow-y-auto pb-20">
      <div className="px-4 py-4 space-y-4">
        {/* Заголовок */}
        <h2 className="text-white text-lg font-medium">Турниры</h2>

        {/* Фильтры */}
        <div className="flex gap-2">
          {[
            { id: 'all' as FilterType, label: 'Все' },
            { id: 'upcoming' as FilterType, label: 'Предстоящие' },
            { id: 'registered' as FilterType, label: 'Мои' },
          ].map((filter) => (
            <button
              key={filter.id}
              onClick={() => handleFilterChange(filter.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeFilter === filter.id
                  ? 'bg-lime-500 text-white'
                  : `${bgCard} text-gray-400 hover:bg-[#333333]`
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>

        {/* Список турниров */}
        <div className="space-y-3">
          {filteredTournaments.length === 0 ? (
            <div className={`${bgCard} rounded-lg p-6 text-center`}>
              <div className="text-4xl mb-2">🏆</div>
              <p className="text-gray-400 text-sm">Турниры не найдены</p>
              {activeFilter === 'registered' && (
                <p className="text-gray-500 text-xs mt-1">
                  Вы пока не зарегистрированы ни на один турнир
                </p>
              )}
            </div>
          ) : (
            filteredTournaments.map((tournament) => (
              <div key={tournament.id} className={`${bgCard} rounded-lg p-3 space-y-2`}>
                {/* Заголовок */}
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-white text-sm font-medium">{tournament.name}</h3>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                        tournament.status === 'upcoming'
                          ? 'bg-lime-500/20 text-lime-400'
                          : tournament.status === 'ongoing'
                          ? 'bg-yellow-500/20 text-yellow-400'
                          : 'bg-gray-500/20 text-gray-400'
                      }`}>
                        {getStatusLabel(tournament.status)}
                      </span>
                      <span className="text-gray-500 text-[10px]">
                        {getTypeLabel(tournament.type)}
                      </span>
                    </div>
                  </div>
                  {tournament.isRegistered && (
                    <span className="bg-lime-500 text-white text-[10px] px-2 py-0.5 rounded-full">
                      Участвую
                    </span>
                  )}
                </div>

                {/* Информация */}
                <div className="space-y-1 text-xs text-gray-300">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3 h-3 text-gray-500" />
                    <span>{tournament.date}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-3 h-3 text-gray-500" />
                    <span>{tournament.location}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Users className="w-3 h-3 text-gray-500" />
                    <span>
                      {tournament.participants}/{tournament.maxParticipants} участников
                    </span>
                    {tournament.participants >= tournament.maxParticipants && (
                      <span className="text-red-400">(мест нет)</span>
                    )}
                  </div>
                  {tournament.prize && (
                    <div className="flex items-center gap-1.5">
                      <Trophy className="w-3 h-3 text-yellow-500" />
                      <span className="text-yellow-400">{tournament.prize}</span>
                    </div>
                  )}
                </div>

                {/* Кнопки */}
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={() => handleViewDetails(tournament)}
                    className="flex-1 flex items-center justify-center gap-1 bg-[#333333] hover:bg-[#404040] text-white py-2 rounded-lg text-xs transition-colors active:scale-[0.98]"
                  >
                    Подробнее
                    <ChevronRight className="w-3 h-3" />
                  </button>
                  {!tournament.isRegistered && tournament.status === 'upcoming' && (
                    <button
                      onClick={() => handleRegister(tournament)}
                      disabled={tournament.participants >= tournament.maxParticipants}
                      className="flex-1 bg-lime-500 hover:bg-lime-600 disabled:opacity-50 disabled:cursor-not-allowed text-white py-2 rounded-lg text-xs font-medium transition-colors active:scale-[0.98]"
                    >
                      Участвовать
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
