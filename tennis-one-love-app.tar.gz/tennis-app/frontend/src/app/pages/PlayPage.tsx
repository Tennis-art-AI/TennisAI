import { useState } from 'react';
import { Plus, X, Clock, MapPin, Calendar, Target } from 'lucide-react';
import { useTelegram } from '../hooks/useTelegram';

interface GameRequest {
  id: string;
  playerName: string;
  playerRating: number;
  court: string;
  date: string;
  time: string;
  duration: number;
  seekingLevelRange: [number, number];
  comment?: string;
}

// Тестовые заявки на игру
const mockRequests: GameRequest[] = [
  {
    id: '1',
    playerName: 'Алекс М.',
    playerRating: 1520,
    court: 'Лужники, корт №3',
    date: '25 янв',
    time: '14:00',
    duration: 90,
    seekingLevelRange: [1400, 1600],
    comment: 'Ищу партнёра на тренировку',
  },
  {
    id: '2',
    playerName: 'Мария К.',
    playerRating: 1480,
    court: 'ЦСКА, открытый корт',
    date: '26 янв',
    time: '10:00',
    duration: 60,
    seekingLevelRange: [1350, 1550],
  },
  {
    id: '3',
    playerName: 'Дмитрий П.',
    playerRating: 1590,
    court: 'Динамо, корт №1',
    date: '27 янв',
    time: '18:00',
    duration: 120,
    seekingLevelRange: [1500, 1700],
    comment: 'Готовлюсь к турниру',
  },
];

export function PlayPage() {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [requests] = useState<GameRequest[]>(mockRequests);
  
  // Форма создания заявки
  const [formData, setFormData] = useState({
    court: '',
    date: '',
    time: '',
    duration: 60,
    minLevel: 1400,
    maxLevel: 1600,
    comment: '',
  });

  const { colorScheme, hapticImpact, hapticNotification, showAlert } = useTelegram();

  const bgCard = colorScheme === 'dark' ? 'bg-[#2a2a2a]' : 'bg-gray-100';

  const handleCreateRequest = () => {
    hapticImpact('medium');
    setShowCreateForm(true);
  };

  const handleCloseForm = () => {
    hapticImpact('light');
    setShowCreateForm(false);
  };

  const handleSubmitRequest = async () => {
    hapticImpact('medium');
    
    if (!formData.court || !formData.date || !formData.time) {
      hapticNotification('error');
      showAlert('Заполните все обязательные поля');
      return;
    }

    // TODO: Отправка на сервер
    hapticNotification('success');
    showAlert('Заявка успешно создана!');
    setShowCreateForm(false);
    setFormData({
      court: '',
      date: '',
      time: '',
      duration: 60,
      minLevel: 1400,
      maxLevel: 1600,
      comment: '',
    });
  };

  const handleRespond = (requestId: string) => {
    hapticImpact('medium');
    hapticNotification('success');
    showAlert('Вы откликнулись на заявку! Ожидайте подтверждения.');
  };

  const calculateEndTime = (startTime: string, duration: number): string => {
    const [hours, minutes] = startTime.split(':').map(Number);
    const endMinutes = hours * 60 + minutes + duration;
    const endHours = Math.floor(endMinutes / 60) % 24;
    const endMins = endMinutes % 60;
    return `${endHours.toString().padStart(2, '0')}:${endMins.toString().padStart(2, '0')}`;
  };

  // Форма создания заявки
  if (showCreateForm) {
    return (
      <div className="flex-1 overflow-y-auto pb-20">
        <div className="px-4 py-4 space-y-4">
          {/* Заголовок */}
          <div className="flex items-center justify-between">
            <h2 className="text-white text-lg font-medium">Создать заявку</h2>
            <button
              onClick={handleCloseForm}
              className="w-8 h-8 rounded-full bg-[#2a2a2a] flex items-center justify-center"
            >
              <X className="w-4 h-4 text-gray-400" />
            </button>
          </div>

          {/* Корт */}
          <div className="space-y-1.5">
            <label className="text-gray-400 text-xs">Корт *</label>
            <input
              type="text"
              value={formData.court}
              onChange={(e) => setFormData({ ...formData, court: e.target.value })}
              placeholder="Например: Лужники, корт №3"
              className={`w-full ${bgCard} text-white rounded-lg px-4 py-3 text-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-lime-500`}
            />
          </div>

          {/* Дата и время */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-gray-400 text-xs">Дата *</label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className={`w-full ${bgCard} text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-lime-500`}
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-gray-400 text-xs">Время *</label>
              <input
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                className={`w-full ${bgCard} text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-lime-500`}
              />
            </div>
          </div>

          {/* Длительность */}
          <div className="space-y-1.5">
            <label className="text-gray-400 text-xs">Длительность (минут)</label>
            <select
              value={formData.duration}
              onChange={(e) => setFormData({ ...formData, duration: Number(e.target.value) })}
              className={`w-full ${bgCard} text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-lime-500`}
            >
              <option value={60}>60 минут</option>
              <option value={90}>90 минут</option>
              <option value={120}>120 минут</option>
            </select>
          </div>

          {/* Уровень соперника */}
          <div className="space-y-1.5">
            <label className="text-gray-400 text-xs">Рейтинг соперника</label>
            <div className="grid grid-cols-2 gap-3">
              <input
                type="number"
                value={formData.minLevel}
                onChange={(e) => setFormData({ ...formData, minLevel: Number(e.target.value) })}
                placeholder="От"
                className={`w-full ${bgCard} text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-lime-500`}
              />
              <input
                type="number"
                value={formData.maxLevel}
                onChange={(e) => setFormData({ ...formData, maxLevel: Number(e.target.value) })}
                placeholder="До"
                className={`w-full ${bgCard} text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-lime-500`}
              />
            </div>
          </div>

          {/* Комментарий */}
          <div className="space-y-1.5">
            <label className="text-gray-400 text-xs">Комментарий</label>
            <textarea
              value={formData.comment}
              onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
              placeholder="Дополнительная информация..."
              rows={3}
              className={`w-full ${bgCard} text-white rounded-lg px-4 py-3 text-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-lime-500 resize-none`}
            />
          </div>

          {/* Кнопка создания */}
          <button
            onClick={handleSubmitRequest}
            className="w-full bg-lime-500 hover:bg-lime-600 text-white py-3 rounded-lg font-medium transition-colors active:scale-[0.98]"
          >
            Создать заявку
          </button>
        </div>
      </div>
    );
  }

  // Основной экран с заявками
  return (
    <div className="flex-1 overflow-y-auto pb-20">
      <div className="px-4 py-4 space-y-4">
        {/* Заголовок и кнопка создания */}
        <div className="flex items-center justify-between">
          <h2 className="text-white text-lg font-medium">Найти игру</h2>
          <button
            onClick={handleCreateRequest}
            className="flex items-center gap-1.5 bg-lime-500 hover:bg-lime-600 text-white px-3 py-1.5 rounded-lg text-sm font-medium transition-colors active:scale-[0.98]"
          >
            <Plus className="w-4 h-4" />
            Создать
          </button>
        </div>

        {/* Активные заявки */}
        <div className="space-y-3">
          {requests.length === 0 ? (
            <div className={`${bgCard} rounded-lg p-6 text-center`}>
              <div className="text-4xl mb-2">🎾</div>
              <p className="text-gray-400 text-sm">Пока нет активных заявок</p>
              <p className="text-gray-500 text-xs mt-1">Создайте первую заявку!</p>
            </div>
          ) : (
            requests.map((request) => (
              <div key={request.id} className={`${bgCard} rounded-lg p-3 space-y-2`}>
                {/* Игрок */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-lime-500 rounded-full flex items-center justify-center text-white font-bold text-xs">
                      {request.playerName.charAt(0)}
                    </div>
                    <div>
                      <div className="text-white text-sm font-medium">{request.playerName}</div>
                      <div className="text-gray-400 text-xs">Рейтинг: {request.playerRating}</div>
                    </div>
                  </div>
                </div>

                {/* Детали */}
                <div className="space-y-1 text-xs text-gray-300">
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-3 h-3 text-gray-500" />
                    <span>{request.court}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3 h-3 text-gray-500" />
                    <span>{request.date}</span>
                    <Clock className="w-3 h-3 text-gray-500 ml-2" />
                    <span>{request.time} - {calculateEndTime(request.time, request.duration)}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Target className="w-3 h-3 text-gray-500" />
                    <span>Ищет: {request.seekingLevelRange[0]} - {request.seekingLevelRange[1]}</span>
                  </div>
                  {request.comment && (
                    <p className="text-gray-400 italic mt-1">"{request.comment}"</p>
                  )}
                </div>

                {/* Кнопка отклика */}
                <button
                  onClick={() => handleRespond(request.id)}
                  className="w-full bg-lime-500 hover:bg-lime-600 text-white py-2 rounded-lg text-xs font-medium transition-colors active:scale-[0.98]"
                >
                  Откликнуться
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
