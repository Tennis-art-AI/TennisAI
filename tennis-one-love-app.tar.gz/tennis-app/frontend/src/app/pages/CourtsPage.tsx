import { useState } from 'react';
import { MapPin, Clock, Phone, Star, ExternalLink } from 'lucide-react';
import { useTelegram } from '../hooks/useTelegram';

interface Court {
  id: string;
  name: string;
  address: string;
  rating: number;
  reviewCount: number;
  type: 'indoor' | 'outdoor';
  surface: string;
  price: string;
  workingHours: string;
  phone?: string;
  isFree: boolean;
}

// Тестовые данные кортов
const mockCourts: Court[] = [
  {
    id: '1',
    name: 'Теннисный центр "Лужники"',
    address: 'Лужнецкая наб., 24',
    rating: 4.8,
    reviewCount: 156,
    type: 'indoor',
    surface: 'Хард',
    price: 'от 2500 ₽/час',
    workingHours: '07:00 - 23:00',
    phone: '+7 (495) 123-45-67',
    isFree: false,
  },
  {
    id: '2',
    name: 'Корты ЦСКА',
    address: 'Ленинградский пр-т, 39',
    rating: 4.6,
    reviewCount: 89,
    type: 'outdoor',
    surface: 'Грунт',
    price: 'от 1800 ₽/час',
    workingHours: '08:00 - 21:00',
    phone: '+7 (495) 234-56-78',
    isFree: false,
  },
  {
    id: '3',
    name: 'Парк Горького (бесплатные)',
    address: 'ул. Крымский Вал, 9',
    rating: 4.2,
    reviewCount: 234,
    type: 'outdoor',
    surface: 'Хард',
    price: 'Бесплатно',
    workingHours: '06:00 - 22:00',
    isFree: true,
  },
  {
    id: '4',
    name: 'Теннисный клуб "Динамо"',
    address: 'Ленинградский пр-т, 36',
    rating: 4.7,
    reviewCount: 112,
    type: 'indoor',
    surface: 'Хард',
    price: 'от 3000 ₽/час',
    workingHours: '07:00 - 23:00',
    phone: '+7 (495) 345-67-89',
    isFree: false,
  },
];

type TabType = 'list' | 'map';

export function CourtsPage() {
  const [activeTab, setActiveTab] = useState<TabType>('list');
  const [filterFree, setFilterFree] = useState(false);
  
  const { colorScheme, hapticImpact, openLink } = useTelegram();

  const bgCard = colorScheme === 'dark' ? 'bg-[#2a2a2a]' : 'bg-gray-100';

  const handleTabChange = (tab: TabType) => {
    hapticImpact('light');
    setActiveTab(tab);
  };

  const handleToggleFilter = () => {
    hapticImpact('light');
    setFilterFree(!filterFree);
  };

  const handleCallCourt = (phone: string) => {
    hapticImpact('medium');
    openLink(`tel:${phone}`);
  };

  const handleOpenMap = (address: string) => {
    hapticImpact('medium');
    openLink(`https://yandex.ru/maps/?text=${encodeURIComponent(address)}`);
  };

  const filteredCourts = filterFree ? mockCourts.filter((c) => c.isFree) : mockCourts;

  return (
    <div className="flex-1 overflow-y-auto pb-20">
      <div className="px-4 py-4 space-y-4">
        {/* Вкладки */}
        <div className="flex gap-2">
          <button
            onClick={() => handleTabChange('list')}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'list'
                ? 'bg-lime-500 text-white'
                : `${bgCard} text-gray-400 hover:bg-[#333333]`
            }`}
          >
            Список кортов
          </button>
          <button
            onClick={() => handleTabChange('map')}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'map'
                ? 'bg-lime-500 text-white'
                : `${bgCard} text-gray-400 hover:bg-[#333333]`
            }`}
          >
            На карте
          </button>
        </div>

        {/* Фильтр бесплатных */}
        <button
          onClick={handleToggleFilter}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
            filterFree
              ? 'bg-lime-500 text-white'
              : `${bgCard} text-gray-400`
          }`}
        >
          <div className={`w-3 h-3 rounded border ${filterFree ? 'bg-white border-white' : 'border-gray-500'}`}>
            {filterFree && <span className="block w-full h-full text-lime-500 text-[8px] leading-3 text-center">✓</span>}
          </div>
          Только бесплатные
        </button>

        {/* Контент */}
        {activeTab === 'list' ? (
          <div className="space-y-3">
            {filteredCourts.length === 0 ? (
              <div className={`${bgCard} rounded-lg p-6 text-center`}>
                <div className="text-4xl mb-2">🎾</div>
                <p className="text-gray-400 text-sm">Корты не найдены</p>
              </div>
            ) : (
              filteredCourts.map((court) => (
                <div key={court.id} className={`${bgCard} rounded-lg p-3 space-y-2`}>
                  {/* Название и рейтинг */}
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-white text-sm font-medium">{court.name}</h3>
                      <div className="flex items-center gap-1 mt-0.5">
                        <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                        <span className="text-white text-xs">{court.rating}</span>
                        <span className="text-gray-500 text-xs">({court.reviewCount})</span>
                      </div>
                    </div>
                    {court.isFree && (
                      <span className="bg-lime-500/20 text-lime-400 text-[10px] px-2 py-0.5 rounded-full">
                        Бесплатно
                      </span>
                    )}
                  </div>

                  {/* Информация */}
                  <div className="space-y-1 text-xs text-gray-300">
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3 h-3 text-gray-500 flex-shrink-0" />
                      <span>{court.address}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3 h-3 text-gray-500" />
                      <span>{court.workingHours}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-gray-500">Покрытие:</span>
                      <span>{court.surface}</span>
                      <span className="text-gray-500">•</span>
                      <span>{court.type === 'indoor' ? 'Крытый' : 'Открытый'}</span>
                    </div>
                    {!court.isFree && (
                      <div className="text-lime-400 font-medium">{court.price}</div>
                    )}
                  </div>

                  {/* Кнопки */}
                  <div className="flex gap-2 pt-1">
                    {court.phone && (
                      <button
                        onClick={() => handleCallCourt(court.phone!)}
                        className="flex-1 flex items-center justify-center gap-1.5 bg-[#333333] hover:bg-[#404040] text-white py-2 rounded-lg text-xs transition-colors active:scale-[0.98]"
                      >
                        <Phone className="w-3 h-3" />
                        Позвонить
                      </button>
                    )}
                    <button
                      onClick={() => handleOpenMap(court.address)}
                      className="flex-1 flex items-center justify-center gap-1.5 bg-lime-500 hover:bg-lime-600 text-white py-2 rounded-lg text-xs transition-colors active:scale-[0.98]"
                    >
                      <ExternalLink className="w-3 h-3" />
                      На карте
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        ) : (
          // Заглушка для карты
          <div className={`${bgCard} rounded-lg p-6 text-center min-h-[400px] flex flex-col items-center justify-center`}>
            <div className="text-5xl mb-3">🗺️</div>
            <h3 className="text-white text-base font-medium mb-1">Карта кортов</h3>
            <p className="text-gray-400 text-sm">
              Интерактивная карта будет доступна в следующей версии
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
