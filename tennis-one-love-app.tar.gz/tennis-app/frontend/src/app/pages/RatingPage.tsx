import { useState } from 'react';
import { Search } from 'lucide-react';
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis } from 'recharts';
import { useTelegram } from '../hooks/useTelegram';

// Данные для графиков
const ratingDataLast5 = [
  { month: 'Фев', rating: 1450 },
  { month: 'Мар', rating: 1480 },
  { month: 'Апр', rating: 1465 },
  { month: 'Май', rating: 1510 },
  { month: 'Июн', rating: 1548 },
];

const ratingDataLast10 = [
  { month: 'Янв', rating: 1420 },
  { month: 'Фев', rating: 1450 },
  { month: 'Мар', rating: 1480 },
  { month: 'Апр', rating: 1465 },
  { month: 'Май', rating: 1510 },
  { month: 'Июн', rating: 1548 },
];

// Список игроков
const allPlayers = [
  { id: 1, name: 'Иван Петров', city: 'Москва', rating: 1548 },
  { id: 2, name: 'Алекс Морган', city: 'Санкт-Петербург', rating: 1532 },
  { id: 3, name: 'Джордан Ли', city: 'Казань', rating: 1518 },
  { id: 4, name: 'Сэм Тейлор', city: 'Новосибирск', rating: 1505 },
  { id: 5, name: 'Мария Гарсия', city: 'Екатеринбург', rating: 1490 },
  { id: 6, name: 'Дэвид Смит', city: 'Нижний Новгород', rating: 1475 },
  { id: 7, name: 'Анна Джонсон', city: 'Челябинск', rating: 1460 },
  { id: 8, name: 'Карлос Родригес', city: 'Самара', rating: 1445 },
  { id: 9, name: 'Эмили Браун', city: 'Омск', rating: 1430 },
  { id: 10, name: 'Майкл Уилсон', city: 'Ростов-на-Дону', rating: 1415 },
];

type FilterType = 'last5' | 'last10' | 'all';

export function RatingPage() {
  const [activeFilter, setActiveFilter] = useState<FilterType>('last5');
  const [showAllPlayers, setShowAllPlayers] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const { colorScheme, hapticImpact } = useTelegram();

  const getCurrentData = () => {
    switch (activeFilter) {
      case 'last5':
        return ratingDataLast5;
      case 'last10':
      case 'all':
        return ratingDataLast10;
      default:
        return ratingDataLast10;
    }
  };

  const filteredPlayers = allPlayers.filter((player) =>
    player.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleFilterChange = (filter: FilterType) => {
    hapticImpact('light');
    setActiveFilter(filter);
  };

  const handleShowAllPlayers = () => {
    hapticImpact('medium');
    setShowAllPlayers(true);
  };

  const handleBack = () => {
    hapticImpact('light');
    setShowAllPlayers(false);
    setSearchQuery('');
  };

  const bgCard = colorScheme === 'dark' ? 'bg-[#2a2a2a]' : 'bg-gray-100';

  // Экран со списком всех игроков
  if (showAllPlayers) {
    return (
      <div className="flex-1 overflow-hidden pb-20 flex flex-col">
        {/* Заголовок и поиск */}
        <div className="px-4 py-3 space-y-3 flex-shrink-0">
          <h2 className="text-white text-lg font-medium">Рейтинг игроков</h2>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              placeholder="Найти игрока"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full ${bgCard} text-white rounded-lg pl-10 pr-4 py-2.5 text-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-lime-500`}
            />
          </div>
        </div>

        {/* Список игроков */}
        <div className="flex-1 overflow-y-auto px-4 pb-4">
          <div className="space-y-2">
            {filteredPlayers.map((player, index) => (
              <div
                key={player.id}
                className={`${bgCard} rounded-lg p-3 flex items-center justify-between`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-lime-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                    {index + 1}
                  </div>
                  <div>
                    <div className="text-white text-sm font-medium">{player.name}</div>
                    <div className="text-gray-400 text-xs">{player.city}</div>
                  </div>
                </div>
                <div className="text-white font-bold text-base">{player.rating}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Кнопка назад */}
        <div className="px-4 pb-3 flex-shrink-0">
          <button
            onClick={handleBack}
            className="w-full bg-lime-500 hover:bg-lime-600 text-white py-3 rounded-lg font-medium transition-colors active:scale-[0.98]"
          >
            Назад
          </button>
        </div>
      </div>
    );
  }

  // Основной экран рейтинга
  return (
    <div className="flex-1 overflow-y-auto overflow-x-hidden pb-20">
      <div className="px-4 py-4 space-y-4">
        {/* Заголовок с рейтингом */}
        <div className="flex items-baseline gap-2">
          <span className="text-gray-400 text-sm">Мой рейтинг</span>
          <span className="text-white font-bold text-xl">1548</span>
        </div>

        {/* Фильтры */}
        <div className="flex gap-3">
          {[
            { id: 'last5' as FilterType, label: 'Последние 5' },
            { id: 'last10' as FilterType, label: 'Последние 10' },
            { id: 'all' as FilterType, label: 'Все игры' },
          ].map((filter) => (
            <button
              key={filter.id}
              onClick={() => handleFilterChange(filter.id)}
              className={`text-xs font-medium transition-colors ${
                activeFilter === filter.id
                  ? 'text-lime-400 underline underline-offset-4'
                  : 'text-gray-400 hover:text-gray-300'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>

        {/* График */}
        <div className={`${bgCard} rounded-lg p-3`}>
          <h3 className="text-white text-sm font-medium mb-2">Динамика рейтинга</h3>
          <div className="h-32">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={getCurrentData()} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <XAxis dataKey="month" stroke="#6b7280" style={{ fontSize: '10px' }} />
                <YAxis stroke="#6b7280" style={{ fontSize: '10px' }} domain={[1400, 1600]} width={35} />
                <Line
                  type="monotone"
                  dataKey="rating"
                  stroke="#84cc16"
                  strokeWidth={2}
                  dot={{ fill: '#84cc16', r: 3 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Статистика */}
        <div className="grid grid-cols-2 gap-3">
          <div className={`${bgCard} rounded-lg p-3`}>
            <h4 className="text-gray-400 text-xs mb-2">Одиночные игры</h4>
            <div className="flex items-baseline justify-between">
              <span className="text-white font-medium text-lg">25</span>
              <span className="text-lime-400 text-sm">80% побед</span>
            </div>
          </div>
          <div className={`${bgCard} rounded-lg p-3`}>
            <h4 className="text-gray-400 text-xs mb-2">Парные игры</h4>
            <div className="flex items-baseline justify-between">
              <span className="text-white font-medium text-lg">12</span>
              <span className="text-lime-400 text-sm">83% побед</span>
            </div>
          </div>
        </div>

        {/* Топ игроков */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-white text-sm font-medium">Топ игроков</h3>
            <button
              onClick={handleShowAllPlayers}
              className="text-lime-400 text-xs hover:text-lime-300 transition-colors"
            >
              Все игроки →
            </button>
          </div>

          {allPlayers.slice(0, 5).map((player, index) => (
            <div
              key={player.id}
              className={`${bgCard} rounded-lg p-2.5 flex items-center justify-between`}
            >
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-lime-500 rounded-full flex items-center justify-center text-white font-bold text-xs">
                  {index + 1}
                </div>
                <div>
                  <div className="text-white text-xs font-medium">{player.name}</div>
                  <div className="text-gray-400 text-[10px]">{player.city}</div>
                </div>
              </div>
              <div className="text-white font-bold text-sm">{player.rating}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
