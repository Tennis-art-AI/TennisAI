# 🎾 Tennis One Love - Telegram Mini App

Telegram Mini App для теннисного сообщества. Позволяет находить партнёров для игры, вести рейтинг и участвовать в турнирах.

## 📋 Содержание

- [Требования](#требования)
- [Быстрый старт](#быстрый-старт)
- [Структура проекта](#структура-проекта)
- [Развёртывание](#развёртывание)
- [API документация](#api-документация)
- [Конфигурация](#конфигурация)

## 🔧 Требования

- Node.js 20+
- Docker & Docker Compose
- PostgreSQL 15+
- Telegram Bot Token

## 🚀 Быстрый старт

### 1. Клонирование и настройка

```bash
# Скопируйте проект на сервер
scp -r tennis-app root@85.239.37.137:/opt/

# Подключитесь к серверу
ssh root@85.239.37.137
cd /opt/tennis-app
```

### 2. Настройка переменных окружения

```bash
# Отредактируйте .env файл с вашими данными
nano .env
```

### 3. Запуск через Docker

```bash
# Сборка и запуск
docker compose up -d --build

# Проверка логов
docker compose logs -f

# Проверка здоровья
curl http://localhost:4000/api/health
```

### 4. Настройка бота в Telegram

1. Откройте @BotFather
2. Выберите вашего бота: @Tennisonelovebot
3. Bot Settings → Menu Button
4. Укажите URL: `https://tennis-all.ru`

## 📁 Структура проекта

```
tennis-app/
├── frontend/                 # React приложение
│   ├── src/
│   │   ├── app/             # Компоненты страниц
│   │   ├── api/             # API клиент
│   │   ├── hooks/           # React хуки
│   │   ├── store/           # Zustand store
│   │   ├── types/           # TypeScript типы
│   │   └── styles/          # CSS стили
│   ├── Dockerfile
│   └── package.json
│
├── backend/                  # Node.js + Fastify API
│   ├── src/
│   │   ├── routes/          # API маршруты
│   │   ├── services/        # Бизнес-логика
│   │   ├── utils/           # Утилиты
│   │   └── middleware/      # Middleware
│   ├── prisma/              # Prisma схема БД
│   ├── Dockerfile
│   └── package.json
│
├── nginx/                    # Nginx конфигурация
├── scripts/                  # Скрипты деплоя
├── docker-compose.yml
└── .env
```

## 🌐 Развёртывание

### Автоматическое развёртывание

```bash
# Из корня проекта на локальной машине
chmod +x scripts/deploy.sh
./scripts/deploy.sh
```

### Ручное развёртывание

```bash
# На сервере
cd /opt/tennis-app

# Остановить старые контейнеры
docker compose down

# Собрать и запустить
docker compose up -d --build

# Применить миграции БД
cd backend
npx prisma migrate deploy
```

### Получение SSL сертификата

```bash
# Certbot (Let's Encrypt)
certbot certonly --standalone -d tennis-all.ru

# Копировать в nginx
cp /etc/letsencrypt/live/tennis-all.ru/fullchain.pem nginx/ssl/
cp /etc/letsencrypt/live/tennis-all.ru/privkey.pem nginx/ssl/
```

## 📚 API Документация

### Авторизация

#### POST /api/auth/telegram
Авторизация через Telegram WebApp.

Headers:
```
X-Telegram-Init-Data: <initData from Telegram>
```

Response:
```json
{
  "success": true,
  "user": {
    "id": 1,
    "firstName": "Иван",
    "rating": 1500
  },
  "token": "session_token"
}
```

#### POST /api/auth/email/send-code
Отправка кода подтверждения на email.

Body:
```json
{
  "email": "user@example.com"
}
```

### Пользователи

#### GET /api/users/rating
Получить рейтинг игроков.

Query params:
- `limit` - количество (default: 20)
- `offset` - смещение (default: 0)
- `search` - поиск по имени

#### GET /api/users/:id
Получить профиль пользователя.

### Игры

#### POST /api/games
Создать новую игру.

Body:
```json
{
  "opponentId": 2,
  "score": "6:2, 6:3",
  "winnerId": 1,
  "courtId": 1,
  "playedAt": "2026-01-23T14:00:00Z"
}
```

### Заявки на игру

#### GET /api/play-requests
Получить активные заявки.

#### POST /api/play-requests
Создать заявку на игру.

Body:
```json
{
  "date": "2026-01-24",
  "time": "14:00",
  "duration": 60,
  "minLevel": 1200,
  "maxLevel": 1800,
  "comment": "Ищу партнёра для спарринга"
}
```

## ⚙️ Конфигурация

### Переменные окружения (.env)

```env
# Telegram
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_BOT_USERNAME=YourBotUsername

# Database
DATABASE_URL=postgresql://user:pass@host:5432/db

# JWT
JWT_SECRET=your_secret_key

# S3 Storage
S3_ACCESS_KEY_ID=your_key
S3_SECRET_ACCESS_KEY=your_secret
S3_ENDPOINT=https://s3.example.com
S3_BUCKET=your_bucket

# Sentry
SENTRY_DSN_FRONTEND=https://...
SENTRY_DSN_BACKEND=https://...
```

## 🔒 Безопасность

- Все данные передаются по HTTPS
- Telegram initData валидируется на бэкенде
- Сессии хранятся в PostgreSQL
- Rate limiting на API эндпоинтах
- CORS настроен только для доверенных доменов

## 📊 Мониторинг

- **Sentry**: Отслеживание ошибок
- **PostgreSQL Exporter**: Метрики БД
- **Docker healthcheck**: Проверка состояния контейнеров

## 🛠 Команды разработки

```bash
# Frontend
cd frontend
npm install
npm run dev        # Запуск dev сервера
npm run build      # Сборка для продакшена

# Backend
cd backend
npm install
npm run dev        # Запуск с hot-reload
npm run build      # Сборка TypeScript
npm run db:migrate # Миграции БД
npm run db:studio  # Prisma Studio (GUI для БД)
```

## 📞 Поддержка

При возникновении проблем:
1. Проверьте логи: `docker compose logs -f`
2. Проверьте здоровье: `curl http://localhost:4000/api/health`
3. Проверьте Sentry на наличие ошибок

---

**Tennis One Love** © 2026
