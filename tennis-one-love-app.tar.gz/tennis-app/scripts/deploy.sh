#!/bin/bash

# Tennis One Love - Deploy Script
# Usage: ./deploy.sh

set -e

echo "🎾 Tennis One Love - Deployment Script"
echo "========================================"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
SERVER_IP="85.239.37.137"
SERVER_USER="root"
APP_DIR="/opt/tennis-app"
DOMAIN="tennis-all.ru"

echo -e "${YELLOW}Step 1: Checking prerequisites...${NC}"

# Check if Docker is available on server
ssh $SERVER_USER@$SERVER_IP "docker --version" > /dev/null 2>&1 || {
    echo -e "${YELLOW}Installing Docker on server...${NC}"
    ssh $SERVER_USER@$SERVER_IP "curl -fsSL https://get.docker.com | sh"
}

# Check if Docker Compose is available
ssh $SERVER_USER@$SERVER_IP "docker compose version" > /dev/null 2>&1 || {
    echo -e "${YELLOW}Installing Docker Compose on server...${NC}"
    ssh $SERVER_USER@$SERVER_IP "apt-get update && apt-get install -y docker-compose-plugin"
}

echo -e "${GREEN}✓ Docker is ready${NC}"

echo -e "${YELLOW}Step 2: Creating app directory on server...${NC}"
ssh $SERVER_USER@$SERVER_IP "mkdir -p $APP_DIR"
echo -e "${GREEN}✓ Directory created${NC}"

echo -e "${YELLOW}Step 3: Copying files to server...${NC}"
rsync -avz --progress \
    --exclude 'node_modules' \
    --exclude '.git' \
    --exclude 'dist' \
    --exclude '*.log' \
    ./ $SERVER_USER@$SERVER_IP:$APP_DIR/
echo -e "${GREEN}✓ Files copied${NC}"

echo -e "${YELLOW}Step 4: Setting up SSL certificate...${NC}"
ssh $SERVER_USER@$SERVER_IP << 'ENDSSH'
cd /opt/tennis-app

# Install certbot if needed
if ! command -v certbot &> /dev/null; then
    apt-get update
    apt-get install -y certbot
fi

# Check if SSL certificate exists
if [ ! -f "/etc/letsencrypt/live/tennis-all.ru/fullchain.pem" ]; then
    echo "Generating SSL certificate..."
    certbot certonly --standalone -d tennis-all.ru -d www.tennis-all.ru --non-interactive --agree-tos --email admin@tennis-all.ru || {
        echo "SSL certificate generation failed. Using self-signed for now..."
        mkdir -p nginx/ssl
        openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout nginx/ssl/privkey.pem \
            -out nginx/ssl/fullchain.pem \
            -subj "/CN=tennis-all.ru"
    }
else
    echo "SSL certificate exists"
fi

# Copy SSL certificates
mkdir -p nginx/ssl
cp /etc/letsencrypt/live/tennis-all.ru/fullchain.pem nginx/ssl/ 2>/dev/null || true
cp /etc/letsencrypt/live/tennis-all.ru/privkey.pem nginx/ssl/ 2>/dev/null || true
ENDSSH
echo -e "${GREEN}✓ SSL configured${NC}"

echo -e "${YELLOW}Step 5: Running database migrations...${NC}"
ssh $SERVER_USER@$SERVER_IP << 'ENDSSH'
cd /opt/tennis-app/backend
# Install dependencies and run migrations
docker run --rm -v $(pwd):/app -w /app node:20-alpine sh -c "npm ci && npx prisma migrate deploy"
ENDSSH
echo -e "${GREEN}✓ Database migrations complete${NC}"

echo -e "${YELLOW}Step 6: Building and starting containers...${NC}"
ssh $SERVER_USER@$SERVER_IP << 'ENDSSH'
cd /opt/tennis-app

# Stop existing containers
docker compose down --remove-orphans 2>/dev/null || true

# Build and start
docker compose build --no-cache
docker compose up -d

# Wait for services to start
sleep 10

# Check health
curl -s http://localhost:4000/api/health | grep -q "ok" && echo "Backend is healthy" || echo "Backend health check failed"
ENDSSH
echo -e "${GREEN}✓ Containers started${NC}"

echo -e "${YELLOW}Step 7: Setting up firewall...${NC}"
ssh $SERVER_USER@$SERVER_IP << 'ENDSSH'
# Allow HTTP and HTTPS
ufw allow 80/tcp 2>/dev/null || true
ufw allow 443/tcp 2>/dev/null || true
ENDSSH
echo -e "${GREEN}✓ Firewall configured${NC}"

echo ""
echo -e "${GREEN}========================================"
echo "🎉 Deployment Complete!"
echo "========================================"
echo ""
echo "Your app is now available at:"
echo "  🌐 https://tennis-all.ru"
echo ""
echo "Next steps:"
echo "  1. Go to @BotFather in Telegram"
echo "  2. Select your bot @Tennisonelovebot"
echo "  3. Go to Bot Settings → Menu Button"
echo "  4. Set URL to: https://tennis-all.ru"
echo ""
echo -e "${NC}"
